package com.tarektv.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.tarektv.app.R
import com.tarektv.app.data.remote.Mp3QuranClient
import com.tarektv.app.data.remote.Mp3QuranReciter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class IslamicActivity : AppCompatActivity() {
    private lateinit var list: ListView
    private lateinit var status: TextView
    private var reciters = emptyList<Mp3QuranReciter>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_islamic)
        list = findViewById(R.id.reciterList)
        status = findViewById(R.id.status)
        findViewById<View>(R.id.back).setOnClickListener { finish() }
        list.setOnItemClickListener { _, _, position, _ -> openReciter(reciters[position]) }
        load()
    }

    private fun load() {
        status.text = "جاري تحديث قائمة القراء…"
        lifecycleScope.launch {
            runCatching { loadReciters() }.onSuccess { result ->
                reciters = result.filter { r -> r.name.orEmpty().isNotBlank() && r.moshaf.any { m -> !m.server.isNullOrBlank() && !m.surah_list.isNullOrBlank() } }
                list.adapter = ArrayAdapter(this@IslamicActivity, android.R.layout.simple_list_item_1, reciters.map { "${it.name}\n${it.moshaf.firstOrNull()?.name.orEmpty()}" })
                status.text = "القراء المتاحون: ${reciters.size} — اختر قارئاً"
            }.onFailure { status.text = "تعذر تحديث مكتبة القرآن: ${it.message ?: "خطأ في الاتصال"}" }
        }
    }

    private suspend fun loadReciters(): List<Mp3QuranReciter> = withContext(Dispatchers.IO) { Mp3QuranClient.api.reciters("ar").reciters }

    private fun openReciter(reciter: Mp3QuranReciter) {
        val moshaf = reciter.moshaf.firstOrNull { !it.server.isNullOrBlank() && !it.surah_list.isNullOrBlank() } ?: return
        startActivity(Intent(this, QuranPlayerActivity::class.java).apply {
            putExtra("reciterName", reciter.name.orEmpty())
            putExtra("server", moshaf.server.orEmpty())
            putExtra("surahList", moshaf.surah_list.orEmpty())
        })
    }
}
