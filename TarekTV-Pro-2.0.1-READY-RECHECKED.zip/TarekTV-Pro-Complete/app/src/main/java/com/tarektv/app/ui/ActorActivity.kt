package com.tarektv.app.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.tarektv.app.data.model.MediaType
import com.tarektv.app.databinding.ActivitySectionSearchBinding
import com.tarektv.app.TarekTvApp
import com.tarektv.app.player.PinManager
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class ActorActivity : AppCompatActivity() {
    private lateinit var b: ActivitySectionSearchBinding
    private val app get() = application as TarekTvApp

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivitySectionSearchBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.back.setOnClickListener { finish() }
        val actor = intent.getStringExtra("actor").orEmpty()
        b.title.text = "أعمال: $actor"
        val adapter = MediaAdapter({ m -> open(m) }) { m, value -> lifecycleScope.launch { app.repository.setFavorite(m.id, value) } }
        b.rv.layoutManager = GridLayoutManager(this, 5)
        b.rv.adapter = adapter
        lifecycleScope.launch {
            val sid = intent.getLongExtra("sourceId", app.preferences.activeSourceId)
            val source = app.repository.sources().first().firstOrNull { it.id == sid } ?: app.repository.sources().first().firstOrNull()
            if (source == null) { b.empty.text = "أضف مصدراً أولاً"; return@launch }
            val results = app.repository.search(source.id, actor).filter { it.type == MediaType.MOVIE || it.type == MediaType.SERIES }
            adapter.submit(results)
            b.empty.text = if (results.isEmpty()) "لا توجد أعمال محفوظة لهذا الممثل في المصدر" else ""
        }
    }

    private fun open(m: com.tarektv.app.data.model.MediaEntity) {
        PinManager.runProtected(this, m.sourceId, app.repository.adultKey(m.type, m.id), m.name) {
            val target = if (m.type == MediaType.SERIES) SeriesDetailActivity::class.java else MovieDetailActivity::class.java
            startActivity(Intent(this, target).putExtra("mediaId", m.id).putExtra("sourceId", m.sourceId).putExtra("url", m.url).putExtra("title", m.name))
        }
    }
}
