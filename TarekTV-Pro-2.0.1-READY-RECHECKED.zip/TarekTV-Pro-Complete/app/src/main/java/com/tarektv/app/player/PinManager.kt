package com.tarektv.app.player

import android.app.AlertDialog
import android.content.Context
import android.text.InputType
import android.widget.EditText
import androidx.lifecycle.lifecycleScope
import com.tarektv.app.TarekTvApp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

object PinManager{
    fun runProtected(context:Context,sourceId:Long,key:String,label:String,onAllowed:()->Unit){
        val app=context.applicationContext as TarekTvApp
        if(!app.preferences.parentalLock){onAllowed();return}
        kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch{
            val protected=app.repository.isProtected(sourceId,key)
            if(!protected){withContext(Dispatchers.Main){onAllowed()};return@launch}
            withContext(Dispatchers.Main){
                val input=EditText(context).apply{inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD}
                AlertDialog.Builder(context).setTitle("محتوى محمي").setMessage(label).setView(input).setNegativeButton("إلغاء",null).setPositiveButton("متابعة"){_,_->
                    if(input.text.toString()==app.preferences.pin) onAllowed() else AlertDialog.Builder(context).setMessage("رمز PIN غير صحيح").setPositiveButton("موافق",null).show()
                }.show()
            }
        }
    }
}
