package com.tarektv.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.tarektv.app.TarekTvApp
import com.tarektv.app.data.model.GroupEntity
import com.tarektv.app.data.model.MediaEntity
import com.tarektv.app.data.model.MediaType
import com.tarektv.app.databinding.ActivityLibraryBinding
import com.tarektv.app.player.PinManager
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class LibraryActivity : AppCompatActivity() {
    private lateinit var b: ActivityLibraryBinding
    private val app get() = application as TarekTvApp
    private var sourceId = -1L
    private var type = MediaType.LIVE
    private var selectedGroupId: Long? = null
    private var allItems = emptyList<MediaEntity>()
    private lateinit var adapter: MediaAdapter
    private var groupItems = emptyList<GroupEntity>()

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        b = ActivityLibraryBinding.inflate(layoutInflater)
        setContentView(b.root)
        sourceId = intent.getLongExtra("sourceId", app.preferences.activeSourceId)
        type = intent.getStringExtra("type") ?: MediaType.LIVE
        if (intent.getStringExtra("mode") == "favorites") sourceId = -1L
        setup()
        observe()
    }

    private fun setup() {
        b.empty.text = when (type) {
            MediaType.LIVE -> "القنوات"
            MediaType.MOVIE -> "الأفلام"
            MediaType.SERIES -> "المسلسلات"
            else -> "المكتبة"
        }
        b.rv.layoutManager = GridLayoutManager(this, 5)
        adapter = MediaAdapter({ play(it) }) { item, value -> lifecycleScope.launch { app.repository.setFavorite(item.id, value) } }
        b.rv.adapter = adapter
        b.btnBack.setOnClickListener { finish() }
        b.group.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) { }
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedGroupId = groupItems.getOrNull(position - 1)?.id
                renderItems()
            }
        }
    }

    private fun observe() {
        if (sourceId == -1L) {
            b.group.visibility = View.GONE
            lifecycleScope.launch { app.repository.favorites().collectLatest { allItems = it; renderItems() } }
            return
        }
        lifecycleScope.launch {
            val source = app.repository.sources().first().firstOrNull { it.id == sourceId } ?: app.repository.sources().first().firstOrNull()
            if (source == null) { b.empty.text = "أضف مصدراً أولاً"; return@launch }
            lifecycleScope.launch {
                app.repository.groups(source.id, type).collectLatest { groups ->
                    groupItems = groups
                    val labels = listOf("كل التصنيفات") + groups.map { it.name }
                    b.group.adapter = ArrayAdapter(this@LibraryActivity, android.R.layout.simple_spinner_dropdown_item, labels)
                    b.group.visibility = if (groups.isEmpty()) View.GONE else View.VISIBLE
                }
            }
            lifecycleScope.launch {
                app.repository.media(source.id, type).collectLatest { items -> allItems = items; renderItems() }
            }
        }
    }

    private fun renderItems() {
        val filtered = selectedGroupId?.let { gid -> allItems.filter { it.groupId == gid } } ?: allItems
        adapter.submit(filtered)
        if (filtered.isEmpty()) b.empty.text = "لا يوجد محتوى متاح في هذا التصنيف" else b.empty.text = "${filtered.size} عنصر"
    }

    private fun play(item: MediaEntity) {
        PinManager.runProtected(this, item.sourceId, app.repository.adultKey(item.type, item.id), item.name) {
            val target = when (item.type) {
                MediaType.SERIES -> SeriesDetailActivity::class.java
                MediaType.MOVIE -> MovieDetailActivity::class.java
                else -> PlayerActivity::class.java
            }
            startActivity(Intent(this, target).putExtra("mediaId", item.id).putExtra("sourceId", item.sourceId)
                .putExtra("url", item.url).putExtra("title", item.name).putExtra("subtitle_url", item.subtitleUrl.orEmpty())
                .putExtra("position", item.lastPositionMs).putExtra("type", item.type))
        }
    }
}
