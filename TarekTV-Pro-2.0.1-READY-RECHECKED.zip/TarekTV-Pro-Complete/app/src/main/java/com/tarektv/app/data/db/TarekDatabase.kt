package com.tarektv.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.tarektv.app.data.model.*

@Database(
    entities = [SourceEntity::class, GroupEntity::class, MediaEntity::class, EpgProgramEntity::class, ProtectedRuleEntity::class],
    version = 3,
    exportSchema = false
)
abstract class TarekDatabase : RoomDatabase() {
    abstract fun sourceDao(): SourceDao
    abstract fun groupDao(): GroupDao
    abstract fun mediaDao(): MediaDao
    abstract fun epgDao(): EpgDao
    abstract fun protectedDao(): ProtectedDao

    companion object {
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE media ADD COLUMN actors TEXT")
                db.execSQL("ALTER TABLE media ADD COLUMN subtitleUrl TEXT")
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE media ADD COLUMN epgChannelId TEXT")
            }
        }

        @Volatile private var instance: TarekDatabase? = null

        fun getInstance(context: Context): TarekDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext,
                TarekDatabase::class.java,
                "tarek_tv_pro.db"
            ).addMigrations(MIGRATION_1_2, MIGRATION_2_3).build().also { instance = it }
        }
    }
}
