package com.tarektv.app.data.db

import androidx.room.*
import com.tarektv.app.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface SourceDao {
    @Query("SELECT * FROM sources ORDER BY name COLLATE NOCASE")
    fun observeAll(): Flow<List<SourceEntity>>

    @Query("SELECT * FROM sources WHERE enabled=1 ORDER BY id")
    suspend fun getEnabled(): List<SourceEntity>

    @Query("SELECT * FROM sources WHERE id=:id LIMIT 1")
    suspend fun get(id: Long): SourceEntity?

    @Insert
    suspend fun insert(source: SourceEntity): Long

    @Update
    suspend fun update(source: SourceEntity)

    @Delete
    suspend fun delete(source: SourceEntity)

    @Query("UPDATE sources SET lastSync=:time,lastSyncError=NULL,liveCount=:live,movieCount=:movie,seriesCount=:series WHERE id=:id")
    suspend fun markSuccess(id: Long, time: Long, live: Int, movie: Int, series: Int)

    @Query("UPDATE sources SET lastSyncError=:error WHERE id=:id")
    suspend fun markError(id: Long, error: String)

    @Query("UPDATE sources SET enabled=:enabled WHERE id=:id")
    suspend fun setEnabled(id: Long, enabled: Boolean)
}

@Dao
interface GroupDao {
    @Query("SELECT * FROM groups WHERE sourceId=:sourceId AND type=:type ORDER BY name COLLATE NOCASE")
    fun observe(sourceId: Long, type: String): Flow<List<GroupEntity>>

    @Query("SELECT * FROM groups WHERE sourceId=:sourceId AND type=:type ORDER BY name COLLATE NOCASE")
    suspend fun getAll(sourceId: Long, type: String): List<GroupEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<GroupEntity>)

    @Query("DELETE FROM groups WHERE sourceId=:sourceId AND type=:type")
    suspend fun deleteAll(sourceId: Long, type: String)
}

@Dao
interface MediaDao {
    @Query("SELECT * FROM media WHERE sourceId=:sourceId AND type=:type ORDER BY name COLLATE NOCASE")
    fun observe(sourceId: Long, type: String): Flow<List<MediaEntity>>

    @Query("SELECT * FROM media WHERE sourceId=:sourceId AND type=:type AND groupId=:groupId ORDER BY name COLLATE NOCASE")
    fun observeByGroup(sourceId: Long, type: String, groupId: Long): Flow<List<MediaEntity>>

    @Query("SELECT * FROM media WHERE sourceId=:sourceId AND type=:type AND groupId=:groupId ORDER BY season ASC, episode ASC, name COLLATE NOCASE")
    fun observeEpisodes(sourceId: Long, type: String, groupId: Long): Flow<List<MediaEntity>>

    @Query("SELECT * FROM media WHERE sourceId=:sourceId AND type=:type ORDER BY lastWatched DESC LIMIT 50")
    fun observeHistory(sourceId: Long, type: String): Flow<List<MediaEntity>>

    @Query("SELECT * FROM media WHERE isFavorite=1 ORDER BY name COLLATE NOCASE")
    fun observeFavorites(): Flow<List<MediaEntity>>

    @Query("SELECT * FROM media WHERE id=:id LIMIT 1")
    suspend fun getById(id: Long): MediaEntity?

    @Query("SELECT * FROM media WHERE sourceId=:sourceId AND type=:type ORDER BY name COLLATE NOCASE")
    suspend fun getAll(sourceId: Long, type: String): List<MediaEntity>

    @Query("SELECT * FROM media WHERE sourceId=:sourceId AND type=:type AND remoteId IN (:remoteIds)")
    suspend fun getByRemoteIds(sourceId: Long, type: String, remoteIds: List<String>): List<MediaEntity>

    @Query("SELECT m.* FROM media m LEFT JOIN groups g ON m.groupId=g.id WHERE m.sourceId=:sourceId AND (m.name LIKE '%' || :query || '%' OR m.description LIKE '%' || :query || '%' OR m.actors LIKE '%' || :query || '%' OR g.name LIKE '%' || :query || '%') ORDER BY m.name COLLATE NOCASE LIMIT 100")
    suspend fun search(sourceId: Long, query: String): List<MediaEntity>

    @Query("SELECT m.* FROM media m LEFT JOIN groups g ON m.groupId=g.id WHERE m.sourceId=:sourceId AND (:type='' OR m.type=:type) AND (m.name LIKE '%' || :query || '%' OR m.description LIKE '%' || :query || '%' OR m.actors LIKE '%' || :query || '%' OR g.name LIKE '%' || :query || '%') ORDER BY m.name COLLATE NOCASE LIMIT 100")
    suspend fun searchByTerm(sourceId: Long, type: String, query: String): List<MediaEntity>

    @Query("SELECT * FROM media WHERE sourceId=:sourceId AND type=:type ORDER BY name COLLATE NOCASE")
    suspend fun getLiveChannels(sourceId: Long, type: String = MediaType.LIVE): List<MediaEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<MediaEntity>)

    @Query("DELETE FROM media WHERE sourceId=:sourceId AND type=:type")
    suspend fun deleteAll(sourceId: Long, type: String)

    @Query("DELETE FROM media WHERE sourceId=:sourceId AND type=:episodeType AND groupId NOT IN (SELECT id FROM media WHERE sourceId=:sourceId AND type=:seriesType)")
    suspend fun deleteOrphanEpisodes(sourceId: Long, episodeType: String = MediaType.EPISODE, seriesType: String = MediaType.SERIES)

    @Query("DELETE FROM media WHERE sourceId=:sourceId AND type=:type AND groupId=:groupId")
    suspend fun deleteGroup(sourceId: Long, type: String, groupId: Long)

    @Query("UPDATE media SET isFavorite=:favorite WHERE id=:id")
    suspend fun setFavorite(id: Long, favorite: Boolean)

    @Query("UPDATE media SET lastWatched=:time,watchCount=watchCount+1,lastPositionMs=:position,durationMs=:duration WHERE id=:id")
    suspend fun markWatched(id: Long, time: Long, position: Long, duration: Long)

    @Query("UPDATE media SET lastPositionMs=:position,durationMs=:duration WHERE id=:id")
    suspend fun savePosition(id: Long, position: Long, duration: Long)
}

@Dao
interface EpgDao {
    @Query("SELECT * FROM epg_programs WHERE sourceId=:sourceId AND channelRemoteId=:channelId AND startMs <= :now AND endMs > :now ORDER BY startMs LIMIT 1")
    suspend fun current(sourceId: Long, channelId: String, now: Long): EpgProgramEntity?

    @Query("SELECT * FROM epg_programs WHERE sourceId=:sourceId AND channelRemoteId=:channelId AND startMs >= :now ORDER BY startMs LIMIT 10")
    suspend fun upcoming(sourceId: Long, channelId: String, now: Long): List<EpgProgramEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<EpgProgramEntity>)

    @Query("DELETE FROM epg_programs WHERE sourceId=:sourceId")
    suspend fun deleteSource(sourceId: Long)
}

@Dao
interface ProtectedDao {
    @Query("SELECT EXISTS(SELECT 1 FROM protected_rules WHERE sourceId=:sourceId AND ruleKey=:key)")
    suspend fun isProtected(sourceId: Long, key: String): Boolean

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(rule: ProtectedRuleEntity)

    @Query("DELETE FROM protected_rules WHERE sourceId=:sourceId AND ruleKey=:key")
    suspend fun remove(sourceId: Long, key: String)

    @Query("SELECT * FROM protected_rules WHERE sourceId=:sourceId ORDER BY label")
    fun observe(sourceId: Long): Flow<List<ProtectedRuleEntity>>
}
