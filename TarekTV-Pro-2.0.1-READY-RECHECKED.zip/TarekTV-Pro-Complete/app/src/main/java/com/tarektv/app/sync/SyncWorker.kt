package com.tarektv.app.sync

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.tarektv.app.TarekTvApp

class SyncWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val errors = (applicationContext as TarekTvApp).repository.syncAll()
        return if (errors.isEmpty()) Result.success() else Result.retry()
    }
}
