package com.tarektv.app.ui

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.tarektv.app.R
import com.tarektv.app.data.remote.Mp3QuranClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class QuranPlayerActivity : AppCompatActivity() {
    private lateinit var list: ListView
    private lateinit var status: TextView
    private var names = emptyList<String>()
    private var server = ""
    private var ids = emptyList<Int>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quran_player)
        list = findViewById(R.id.surahList)
        status = findViewById(R.id.status)
        findViewById<TextView>(R.id.title).text = savedInstanceState?.getString("title") ?: intent.getStringExtra("reciterName").orEmpty()
        findViewById<TextView>(R.id.back).setOnClickListener { finish() }
        server = intent.getStringExtra("server").orEmpty().let { if (it.endsWith('/')) it else "$it/" }
        ids = intent.getStringExtra("surahList").orEmpty().split(',').mapNotNull { it.trim().toIntOrNull() }
        list.setOnItemClickListener { _, _, position, _ -> play(ids.getOrNull(position) ?: return@setOnItemClickListener, names.getOrNull(position).orEmpty()) }
        loadNames()
    }

    private fun loadNames() {
        status.text = "جاري تحميل أسماء السور…"
        lifecycleScope.launch {
            runCatching { loadSuras() }.onSuccess { pairs ->
                names = pairs.map { it.second }
                list.adapter = ArrayAdapter(this@QuranPlayerActivity, android.R.layout.simple_list_item_1, names)
                status.text = "${names.size} سورة — اختر سورة للتشغيل"
            }.onFailure { status.text = "تعذر تحميل أسماء السور" }
        }
    }

    private suspend fun loadSuras(): List<Pair<Int, String>> = withContext(Dispatchers.IO) {
        val suwar = Mp3QuranClient.api.suwar("ar").suwar.associateBy { it.id ?: -1 }
        ids.map { id -> id to (suwar[id]?.name ?: "سورة $id") }
    }

    private fun play(id: Int, name: String) {
        // MP3Quran publishes per-surah MP3 files as three-digit names on the supplied server.
        val url = "$server${id.toString().padStart(3, '0')}.mp3"
        startActivity(Intent(this, PlayerActivity::class.java).apply {
            putExtra("url", url)
            putExtra("title", "${intent.getStringExtra("reciterName").orEmpty()} — $name")
            putExtra("type", "QURAN")
        })
    }
}
