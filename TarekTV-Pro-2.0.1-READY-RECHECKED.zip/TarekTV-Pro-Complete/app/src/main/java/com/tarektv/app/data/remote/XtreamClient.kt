package com.tarektv.app.data.remote

import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.net.URI
import java.util.concurrent.TimeUnit

class XtreamClient(base:String){
    private val root=normalize(base)
    val api:XtreamApi=Retrofit.Builder().baseUrl(root).client(OkHttpClient.Builder().connectTimeout(30,TimeUnit.SECONDS).readTimeout(90,TimeUnit.SECONDS).writeTimeout(30,TimeUnit.SECONDS).retryOnConnectionFailure(true).build()).addConverterFactory(GsonConverterFactory.create()).build().create(XtreamApi::class.java)
    private val streamBase=root.removeSuffix("/").removeSuffix("/player_api.php")
    fun url(type:String,id:String,user:String,pass:String,ext:String):String{val path=when(type){"LIVE"->"live";"MOVIE"->"movie";else->"series"};return "$streamBase/$path/$user/$pass/$id.$ext"}
    companion object{fun normalize(input:String):String{val raw=if(input.startsWith("http://",true)||input.startsWith("https://",true))input else "http://$input";val u=URI(raw);val path=when{u.path.isNullOrBlank()->"/";u.path!!.endsWith("/")->u.path!!;else->u.path!!+"/"};return URI(u.scheme,u.userInfo,u.host,u.port,path,null,null).toString()}}
}
