package com.tarektv.app.ui

import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.result.contract.ActivityResultContracts
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import com.google.android.gms.cast.MediaInfo
import com.google.android.gms.cast.MediaLoadRequestData
import com.google.android.gms.cast.MediaMetadata as CastMetadata
import com.google.android.gms.cast.framework.CastButtonFactory
import com.google.android.gms.cast.framework.CastSession
import com.google.android.gms.cast.framework.SessionManagerListener
import com.tarektv.app.TarekTvApp
import com.tarektv.app.data.model.MediaEntity
import com.tarektv.app.data.model.MediaType
import com.tarektv.app.databinding.ActivityPlayerBinding
import com.tarektv.app.player.PlayerEngine
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
class PlayerActivity : AppCompatActivity() {
    private lateinit var b: ActivityPlayerBinding
    private val app get() = application as TarekTvApp
    private var player: androidx.media3.exoplayer.ExoPlayer? = null
    private var mediaId = -1L
    private var sourceId = -1L
    private var mediaType = MediaType.LIVE
    private var current: MediaEntity? = null
    private var liveChannels = emptyList<MediaEntity>()
    private var channelIndex = -1
    private var castStarted = false
    private var localSubtitleUri: Uri? = null

    private val subtitlePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@registerForActivityResult
        localSubtitleUri = uri
        runCatching { contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        startInternal(current?.url ?: intent.getStringExtra("url"), player?.currentPosition ?: 0L)
        Toast.makeText(this, "تم تحميل ملف الترجمة", Toast.LENGTH_SHORT).show()
    }

    private val castListener = object : SessionManagerListener<CastSession> {
        override fun onSessionStarted(session: CastSession, sessionId: String) { loadToCast(session) }
        override fun onSessionResumed(session: CastSession, wasSuspended: Boolean) { if (!castStarted) loadToCast(session) }
        override fun onSessionEnded(session: CastSession, error: Int) { castStarted = false; player?.play() }
        override fun onSessionStartFailed(session: CastSession, error: Int) { castStarted = false; Toast.makeText(this@PlayerActivity, "تعذر بدء Chromecast", Toast.LENGTH_SHORT).show() }
        override fun onSessionStarting(session: CastSession) = Unit
        override fun onSessionEnding(session: CastSession) = Unit
        override fun onSessionResuming(session: CastSession, sessionId: String) = Unit
        override fun onSessionSuspended(session: CastSession, reason: Int) = Unit
    }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        b = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(b.root)
        sourceId = intent.getLongExtra("sourceId", -1L)
        mediaId = intent.getLongExtra("mediaId", -1L)
        mediaType = intent.getStringExtra("type") ?: MediaType.LIVE
        b.title.text = intent.getStringExtra("title").orEmpty()
        b.subtitleButton.setOnClickListener { subtitlePicker.launch(arrayOf("text/srt", "text/vtt", "application/x-subrip", "text/plain")) }
        CastButtonFactory.setUpMediaRouteButton(applicationContext, b.cast)
        appCastManager()?.addSessionManagerListener(castListener, CastSession::class.java)

        lifecycleScope.launch {
            if (mediaId != -1L) current = app.repository.getMedia(mediaId)
            if (mediaType == MediaType.LIVE && sourceId != -1L) {
                liveChannels = app.repository.liveChannels(sourceId)
                channelIndex = liveChannels.indexOfFirst { it.id == mediaId }
            }
            startInternal(intent.getStringExtra("url"), intent.getLongExtra("position", current?.lastPositionMs ?: 0L))
        }
    }

    private fun appCastManager() = runCatching { com.google.android.gms.cast.framework.CastContext.getSharedInstance(this).sessionManager }.getOrNull()

    private fun startInternal(rawUrl: String?, position: Long) {
        val item = current
        val url = rawUrl?.takeIf { it.isNotBlank() } ?: item?.url ?: return
        val title = item?.name ?: intent.getStringExtra("title").orEmpty()
        b.title.text = title
        player?.release()
        player = PlayerEngine.create(this).also { p ->
            b.player.player = p
            val builder = MediaItem.Builder().setUri(url).setMediaMetadata(
                androidx.media3.common.MediaMetadata.Builder().setTitle(title).build()
            )
            PlayerEngine.guessMime(url)?.let(builder::setMimeType)
            val subtitle = localSubtitleUri?.toString()
                ?: intent.getStringExtra("subtitle_url")?.takeIf { it.isNotBlank() }
                ?: item?.subtitleUrl
            subtitle?.let { subtitleUrl ->
                val mime = if (subtitleUrl.contains(".vtt", true)) MimeTypes.TEXT_VTT else MimeTypes.APPLICATION_SUBRIP
                builder.setSubtitleConfigurations(
                    listOf(MediaItem.SubtitleConfiguration.Builder(Uri.parse(subtitleUrl))
                        .setMimeType(mime).setLanguage("ar").setLabel("العربية").setSelectionFlags(androidx.media3.common.C.SELECTION_FLAG_DEFAULT).build())
                )
            }
            p.setMediaItem(builder.build())
            p.prepare()
            if (position > 0L) p.seekTo(position)
            p.playWhenReady = true
            p.addListener(object : Player.Listener {
                override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                    Toast.makeText(this@PlayerActivity, "تعذر تشغيل المصدر: ${error.errorCodeName}", Toast.LENGTH_LONG).show()
                }
            })
        }
    }

    private fun switchChannel(delta: Int) {
        if (liveChannels.isEmpty()) return
        if (channelIndex < 0) channelIndex = liveChannels.indexOfFirst { it.id == mediaId }.coerceAtLeast(0)
        val next = (channelIndex + delta).coerceIn(0, liveChannels.lastIndex)
        if (next == channelIndex) return
        saveCurrentPosition()
        channelIndex = next
        current = liveChannels[next]
        mediaId = current!!.id
        intent.putExtra("mediaId", mediaId)
        intent.putExtra("url", current!!.url)
        intent.putExtra("title", current!!.name)
        intent.putExtra("type", MediaType.LIVE)
        b.title.text = current!!.name
        startInternal(current!!.url, 0L)
        Toast.makeText(this, if (delta > 0) "القناة التالية: ${current!!.name}" else "القناة السابقة: ${current!!.name}", Toast.LENGTH_SHORT).show()
    }

    private fun saveCurrentPosition() {
        val p = player ?: return
        val id = mediaId
        if (id == -1L) return
        lifecycleScope.launch {
            app.repository.savePosition(id, p.currentPosition, p.duration.coerceAtLeast(0L))
            if (p.currentPosition > 30_000L) app.repository.markWatched(id, p.currentPosition, p.duration.coerceAtLeast(0L))
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (mediaType == MediaType.LIVE) {
            when (keyCode) {
                KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_MEDIA_NEXT, KeyEvent.KEYCODE_DPAD_RIGHT -> { switchChannel(1); return true }
                KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_MEDIA_PREVIOUS, KeyEvent.KEYCODE_DPAD_LEFT -> { switchChannel(-1); return true }
                KeyEvent.KEYCODE_DPAD_UP -> { if (liveChannels.isNotEmpty()) { switchChannel(1); return true } }
                KeyEvent.KEYCODE_DPAD_DOWN -> { if (liveChannels.isNotEmpty()) { switchChannel(-1); return true } }
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun loadToCast(session: CastSession) {
        val url = current?.url ?: intent.getStringExtra("url") ?: return
        val type = when {
            url.contains(".m3u8", true) -> "application/x-mpegURL"
            url.contains(".mpd", true) -> "application/dash+xml"
            url.contains(".ts", true) -> "video/mp2t"
            url.contains(".mp3", true) -> "audio/mpeg"
            else -> "video/mp4"
        }
        val metadata = CastMetadata(if (type.startsWith("audio")) CastMetadata.MEDIA_TYPE_MUSIC else CastMetadata.MEDIA_TYPE_MOVIE).apply {
            putString(CastMetadata.KEY_TITLE, b.title.text.toString())
        }
        val info = MediaInfo.Builder(url).setContentType(type).setStreamType(MediaInfo.STREAM_TYPE_BUFFERED).setMetadata(metadata).build()
        session.remoteMediaClient?.load(MediaLoadRequestData.Builder().setMediaInfo(info).build())
        castStarted = true
        player?.pause()
    }

    override fun onPause() {
        saveCurrentPosition()
        super.onPause()
    }

    override fun onDestroy() {
        appCastManager()?.removeSessionManagerListener(castListener, CastSession::class.java)
        b.player.player = null
        player?.release()
        player = null
        super.onDestroy()
    }
}
