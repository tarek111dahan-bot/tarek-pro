package com.tarektv.app.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.tarektv.app.TarekTvApp
import com.tarektv.app.databinding.ActivityLibraryBinding
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class SeriesDetailActivity:AppCompatActivity(){
    private lateinit var b:ActivityLibraryBinding
    private val app get()=application as TarekTvApp
    private lateinit var adapter:MediaAdapter
    private var sourceId=-1L
    private var seriesId=-1L
    override fun onCreate(s:Bundle?){
        super.onCreate(s);b=ActivityLibraryBinding.inflate(layoutInflater);setContentView(b.root)
        sourceId=intent.getLongExtra("sourceId",-1L);seriesId=intent.getLongExtra("mediaId",-1L);b.empty.text="الحلقات";b.btnBack.setOnClickListener{finish()}
        adapter=MediaAdapter({e->startActivity(Intent(this,PlayerActivity::class.java).putExtra("mediaId",e.id).putExtra("sourceId",e.sourceId).putExtra("url",e.url).putExtra("title",e.name).putExtra("subtitle_url",e.subtitleUrl.orEmpty()).putExtra("position",e.lastPositionMs).putExtra("type",e.type))}){e,v->lifecycleScope.launch{app.repository.setFavorite(e.id,v)}}
        b.rv.layoutManager=GridLayoutManager(this,5);b.rv.adapter=adapter
        lifecycleScope.launch{app.repository.loadSeriesEpisodes(sourceId,seriesId);app.repository.episodes(sourceId,seriesId).collectLatest{adapter.submit(it)}}
    }
}
