package com.tarektv.app.data.parser

import com.tarektv.app.data.model.MediaType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.BufferedReader
import java.io.StringReader
import java.util.concurrent.TimeUnit

private val attrRegex = Regex("([\\w-]+)=\"([^\"]*)\"")

data class ParsedM3uItem(
    val name: String,
    val url: String,
    val logo: String?,
    val group: String?,
    val tvgId: String?,
    val type: String,
    val adult: Boolean,
    val subtitleUrl: String? = null
)

class M3uParser {
    private val client = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    suspend fun parse(url: String): List<ParsedM3uItem> = withContext(Dispatchers.IO) {
        val response = client.newCall(
            Request.Builder().url(url).header("User-Agent", "TarekTV/2.0").build()
        ).execute()
        response.use {
            if (!it.isSuccessful) error("HTTP ${it.code}")
            val body = it.body?.string() ?: error("Empty playlist")
            parseText(body)
        }
    }

    fun parseText(text: String): List<ParsedM3uItem> {
        val out = ArrayList<ParsedM3uItem>()
        val reader = BufferedReader(StringReader(text))
        var pendingAttrs: Map<String, String>? = null
        var pendingName: String? = null
        reader.lineSequence().forEach { raw ->
            val line = raw.trim().removePrefix("\uFEFF")
            when {
                line.startsWith("#EXTINF", ignoreCase = true) -> {
                    pendingAttrs = attrRegex.findAll(line.substringAfter(':', ""))
                        .associate { it.groupValues[1].lowercase() to it.groupValues[2] }
                    pendingName = line.substringAfterLast(',').trim().ifBlank { null }
                }
                line.startsWith("#") || line.isBlank() -> Unit
                pendingName != null -> {
                    val attrs = pendingAttrs.orEmpty()
                    val name = pendingName!!
                    val group = attrs["group-title"] ?: attrs["group"]
                    val type = detectType(group, name, line)
                    val adult = isAdult("${group.orEmpty()} $name") || attrs["adult"] == "1"
                    val subtitle = attrs["subtitles"] ?: attrs["subtitle"] ?: attrs["subtitle-url"]
                    out += ParsedM3uItem(
                        name = name,
                        url = line,
                        logo = attrs["tvg-logo"] ?: attrs["logo"],
                        group = group,
                        tvgId = attrs["tvg-id"],
                        type = type,
                        adult = adult,
                        subtitleUrl = subtitle?.ifBlank { null }
                    )
                    pendingAttrs = null
                    pendingName = null
                }
            }
        }
        return out
    }

    private fun detectType(group: String?, name: String, url: String): String {
        val s = "${group.orEmpty()} $name".lowercase()
        val liveMarkers = listOf("live", "channel", "channels", "قناة", "قنوات", "sport", "sports", "news", "radio", "m3u8", ".ts")
        if (liveMarkers.any(s::contains) || url.contains(".m3u8", true) || url.contains(".ts", true)) return MediaType.LIVE
        return when {
            listOf("series", "مسلسل", "مسلسلات", "episode", "season", "حلقة").any(s::contains) -> MediaType.SERIES
            listOf("movie", "movies", "film", "فيلم", "أفلام", "vod").any(s::contains) -> MediaType.MOVIE
            else -> MediaType.LIVE
        }
    }

    private fun isAdult(s: String): Boolean {
        val v = s.lowercase()
        return listOf("xxx", "adult", "18+", "porn", "sex", "إباح", "بالغ").any(v::contains)
    }
}
