package com.tarektv.app.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

object MediaType {
    const val LIVE = "LIVE"
    const val MOVIE = "MOVIE"
    const val SERIES = "SERIES"
    const val EPISODE = "EPISODE"
}

object SourceType {
    const val M3U = "M3U"
    const val XTREAM = "XTREAM"
}

@Entity(tableName = "sources")
data class SourceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val type: String,
    val url: String,
    val username: String? = null,
    val password: String? = null,
    val epgUrl: String? = null,
    val enabled: Boolean = true,
    val addedAt: Long = System.currentTimeMillis(),
    val lastSync: Long? = null,
    val lastSyncError: String? = null,
    val liveCount: Int = 0,
    val movieCount: Int = 0,
    val seriesCount: Int = 0
)

@Entity(
    tableName = "groups",
    indices = [Index(value = ["sourceId", "type", "remoteId"], unique = true)]
)
data class GroupEntity(
    @PrimaryKey val id: Long,
    val sourceId: Long,
    val type: String,
    val remoteId: String,
    val name: String,
    val count: Int = 0
)

@Entity(
    tableName = "media",
    indices = [
        Index(value = ["sourceId", "type", "remoteId"], unique = true),
        Index(value = ["sourceId", "type"]),
        Index(value = ["groupId"]),
        Index(value = ["isFavorite"]),
        Index(value = ["name"])
    ]
)
data class MediaEntity(
    @PrimaryKey val id: Long,
    val sourceId: Long,
    val type: String,
    val remoteId: String,
    val groupId: Long? = null,
    val name: String,
    val url: String,
    val logo: String? = null,
    val description: String? = null,
    val year: Int? = null,
    val season: Int? = null,
    val episode: Int? = null,
    val actors: String? = null,
    val subtitleUrl: String? = null,
    val epgChannelId: String? = null,
    val adult: Boolean = false,
    val isFavorite: Boolean = false,
    val lastWatched: Long? = null,
    val watchCount: Int = 0,
    val lastPositionMs: Long = 0L,
    val durationMs: Long = 0L
)

@Entity(tableName = "epg_programs", indices = [Index(value = ["sourceId", "channelRemoteId", "startMs"])])
data class EpgProgramEntity(
    @PrimaryKey val id: Long,
    val sourceId: Long,
    val channelRemoteId: String,
    val title: String,
    val description: String? = null,
    val startMs: Long,
    val endMs: Long,
    val icon: String? = null
)

@Entity(tableName = "protected_rules", indices = [Index(value = ["sourceId", "ruleKey"], unique = true)])
data class ProtectedRuleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sourceId: Long,
    val ruleKey: String,
    val label: String,
    val createdAt: Long = System.currentTimeMillis()
)
