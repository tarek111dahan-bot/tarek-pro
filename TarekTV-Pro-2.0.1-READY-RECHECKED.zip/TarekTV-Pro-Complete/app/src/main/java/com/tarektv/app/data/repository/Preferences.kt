package com.tarektv.app.data.repository

import android.content.Context

class Preferences(context: Context) {
    private val p = context.getSharedPreferences("tarek_prefs", Context.MODE_PRIVATE)
    var activeSourceId: Long
        get() = p.getLong("active_source_id", -1)
        set(v) = p.edit().putLong("active_source_id", v).apply()
    var parentalLock: Boolean
        get() = p.getBoolean("parental_lock", true)
        set(v) = p.edit().putBoolean("parental_lock", v).apply()
    var pin: String
        get() = p.getString("pin", "4827") ?: "4827"
        set(v) = p.edit().putString("pin", v).apply()
    var syncOnLaunch: Boolean
        get() = p.getBoolean("sync_on_launch", true)
        set(v) = p.edit().putBoolean("sync_on_launch", v).apply()
    var externalPlayerPackage: String?
        get() = p.getString("external_player", null)
        set(v) = p.edit().putString("external_player", v).apply()
}
