package com.tarektv.app.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.tarektv.app.R
import com.tarektv.app.data.model.MediaEntity
import com.tarektv.app.databinding.ItemMediaBinding

class MediaAdapter(private val click:(MediaEntity)->Unit, private val favorite:(MediaEntity,Boolean)->Unit = {_,_->}):RecyclerView.Adapter<MediaAdapter.VH>(){
    private var items=emptyList<MediaEntity>()
    fun submit(v:List<MediaEntity>){items=v;notifyDataSetChanged()}
    override fun onCreateViewHolder(p:ViewGroup,v:Int)=VH(ItemMediaBinding.inflate(LayoutInflater.from(p.context),p,false))
    override fun getItemCount()=items.size
    override fun onBindViewHolder(h:VH,i:Int)=h.bind(items[i])
    inner class VH(private val b:ItemMediaBinding):RecyclerView.ViewHolder(b.root){
        fun bind(item:MediaEntity){b.title.text=item.name;b.star.text=if(item.isFavorite)"★" else "☆";Glide.with(b.logo).load(item.logo).placeholder(R.drawable.ic_placeholder).error(R.drawable.ic_placeholder).centerCrop().into(b.logo);b.root.setOnClickListener{click(item)};b.star.setOnClickListener{val next=!item.isFavorite;b.star.text=if(next)"★" else "☆";favorite(item,next)}}
    }
}
