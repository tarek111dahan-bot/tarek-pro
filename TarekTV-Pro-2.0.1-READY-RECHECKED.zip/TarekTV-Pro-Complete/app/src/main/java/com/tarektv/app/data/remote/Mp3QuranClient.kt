package com.tarektv.app.data.remote

import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object Mp3QuranClient {
    val api: Mp3QuranApi by lazy {
        val client = OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
        Retrofit.Builder()
            .baseUrl("https://www.mp3quran.net/")
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(Mp3QuranApi::class.java)
    }
}
