package com.tarektv.app.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.tarektv.app.TarekTvApp
import com.tarektv.app.R
import com.tarektv.app.data.model.MediaType
import com.tarektv.app.databinding.ActivityEpgBinding
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class EpgActivity:AppCompatActivity(){
    private lateinit var b:ActivityEpgBinding;private val app get()=application as TarekTvApp
    override fun onCreate(s:Bundle?){super.onCreate(s);b=ActivityEpgBinding.inflate(layoutInflater);setContentView(b.root);b.back.setOnClickListener{finish()};b.rv.layoutManager=LinearLayoutManager(this);lifecycleScope.launch{val src=app.repository.sources().first().firstOrNull{it.id==app.preferences.activeSourceId} ?: app.repository.sources().first().firstOrNull();if(src==null){b.empty.text="أضف مصدراً أولاً";return@launch};val channels=app.repository.media(src.id,MediaType.LIVE).first().take(80);val rows=channels.mapNotNull{m->app.repository.currentEpg(src.id,m.epgChannelId ?: m.remoteId)?.let{EpgRow(m.name,it.title,it.startMs,it.endMs)}};b.rv.adapter=EpgAdapter(rows);if(rows.isEmpty())b.empty.text="لا توجد بيانات EPG حالياً. أضف رابط XMLTV للمصدر."}}
    data class EpgRow(val channel:String,val program:String,val start:Long,val end:Long)
}

private class EpgAdapter(private val items:List<EpgActivity.EpgRow>):androidx.recyclerview.widget.RecyclerView.Adapter<EpgAdapter.VH>(){
    override fun onCreateViewHolder(p:android.view.ViewGroup,v:Int)=VH(android.view.LayoutInflater.from(p.context).inflate(R.layout.item_epg,p,false))
    override fun getItemCount()=items.size
    override fun onBindViewHolder(h:VH,i:Int){val x=items[i];h.channel.text=x.channel;h.program.text=x.program;val f=java.text.SimpleDateFormat("HH:mm",java.util.Locale.getDefault());h.time.text="${f.format(java.util.Date(x.start))} - ${f.format(java.util.Date(x.end))}"}
    class VH(v:android.view.View):androidx.recyclerview.widget.RecyclerView.ViewHolder(v){val channel=v.findViewById<android.widget.TextView>(R.id.channel);val program=v.findViewById<android.widget.TextView>(R.id.program);val time=v.findViewById<android.widget.TextView>(R.id.time)}
}
