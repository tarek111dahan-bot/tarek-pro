package com.tarektv.app.data.util

object TextNormalizer {
    fun normalize(value: String): String {
        return value
            .lowercase()
            .replace('أ', 'ا')
            .replace('إ', 'ا')
            .replace('آ', 'ا')
            .replace('ى', 'ي')
            .replace('ة', 'ه')
            .replace(Regex("[ًٌٍَُِّْـ]"), "")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    fun containsAny(value: String?, terms: Collection<String>): Boolean {
        val normalized = normalize(value.orEmpty())
        return terms.any { term -> normalized.contains(normalize(term)) }
    }
}
