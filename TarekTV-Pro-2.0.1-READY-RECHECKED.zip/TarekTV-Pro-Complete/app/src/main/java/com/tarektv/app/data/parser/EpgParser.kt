package com.tarektv.app.data.parser

import com.tarektv.app.data.model.EpgProgramEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

class EpgParser {
    private val client = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    suspend fun download(url: String): String = withContext(Dispatchers.IO) {
        val response = client.newCall(
            Request.Builder().url(url).header("User-Agent", "TarekTV/2.0").build()
        ).execute()
        response.use {
            if (!it.isSuccessful) error("EPG HTTP ${it.code}")
            it.body?.string() ?: error("Empty EPG")
        }
    }

    fun parse(xml: String): List<EpgProgramEntity> {
        val parser = XmlPullParserFactory.newInstance().newPullParser()
        parser.setInput(xml.reader())
        val out = mutableListOf<EpgProgramEntity>()
        var currentTag = ""
        var channel = ""
        var title = StringBuilder()
        var desc = StringBuilder()
        var icon: String? = null
        var start = 0L
        var end = 0L
        var inProgramme = false

        while (parser.eventType != XmlPullParser.END_DOCUMENT) {
            when (parser.eventType) {
                XmlPullParser.START_TAG -> {
                    currentTag = parser.name
                    if (currentTag == "programme") {
                        inProgramme = true
                        channel = parser.getAttributeValue(null, "channel").orEmpty()
                        start = parseTime(parser.getAttributeValue(null, "start"))
                        end = parseTime(parser.getAttributeValue(null, "stop"))
                        title = StringBuilder()
                        desc = StringBuilder()
                        icon = null
                    } else if (inProgramme && currentTag == "icon") {
                        icon = parser.getAttributeValue(null, "src")
                    }
                }
                XmlPullParser.TEXT -> if (inProgramme) {
                    when (currentTag) {
                        "title" -> title.append(parser.text.orEmpty())
                        "desc" -> desc.append(parser.text.orEmpty())
                    }
                }
                XmlPullParser.END_TAG -> {
                    if (parser.name == "programme") {
                        val cleanTitle = title.toString().trim()
                        val cleanDesc = desc.toString().trim()
                        if (channel.isNotBlank() && cleanTitle.isNotBlank() && end > start) {
                            out += EpgProgramEntity(
                                0, 0, channel, cleanTitle,
                                cleanDesc.ifBlank { null }, start, end, icon
                            )
                        }
                        inProgramme = false
                    }
                    currentTag = ""
                }
            }
            parser.next()
        }
        return out
    }

    private fun parseTime(raw: String?): Long {
        if (raw.isNullOrBlank()) return 0L
        val clean = raw.trim()
        for (format in listOf("yyyyMMddHHmmss Z", "yyyyMMddHHmmss")) {
            runCatching {
                val sdf = SimpleDateFormat(format, Locale.US).apply {
                    isLenient = false
                    if (!clean.contains(" ")) timeZone = TimeZone.getDefault()
                }
                return sdf.parse(clean)?.time ?: 0L
            }
        }
        return 0L
    }
}
