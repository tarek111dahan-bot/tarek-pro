package com.tarektv.app.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.tarektv.app.TarekTvApp
import com.tarektv.app.data.model.SourceEntity
import com.tarektv.app.data.model.SourceType
import com.tarektv.app.databinding.ActivityAddSourceBinding
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class AddSourceActivity:AppCompatActivity(){
    private lateinit var b:ActivityAddSourceBinding
    private val app get()=application as TarekTvApp
    override fun onCreate(s:Bundle?){
        super.onCreate(s); b=ActivityAddSourceBinding.inflate(layoutInflater); setContentView(b.root)
        b.back.setOnClickListener{finish()}; b.typeM3u.isChecked=true; b.save.setOnClickListener{save()}
    }
    private fun save(){
        val name=b.name.text?.toString()?.trim().orEmpty(); val url=b.url.text?.toString()?.trim().orEmpty(); val user=b.user.text?.toString()?.trim().orEmpty(); val pass=b.pass.text?.toString().orEmpty()
        if(name.isBlank()||url.isBlank()){Toast.makeText(this,"أدخل الاسم والرابط",Toast.LENGTH_SHORT).show();return}
        val type=if(b.typeM3u.isChecked)SourceType.M3U else SourceType.XTREAM
        if(type==SourceType.XTREAM&&(user.isBlank()||pass.isBlank())){Toast.makeText(this,"أدخل اسم المستخدم وكلمة المرور لـ Xtream",Toast.LENGTH_SHORT).show();return}
        lifecycleScope.launch{
            val id=app.repository.addSource(SourceEntity(name=name,type=type,url=url,username=user.ifBlank{null},password=pass.ifBlank{null},epgUrl=b.epg.text?.toString()?.trim()?.ifBlank{null}))
            app.preferences.activeSourceId=id
            val source=app.repository.sources().first().firstOrNull{it.id==id}
            if(source!=null) runCatching{app.repository.sync(source)}.onFailure{Toast.makeText(this@AddSourceActivity,"تعذر مزامنة المصدر: ${it.message}",Toast.LENGTH_LONG).show()}
            Toast.makeText(this@AddSourceActivity,"تم حفظ المصدر",Toast.LENGTH_SHORT).show(); finish()
        }
    }
}
