package com.tarektv.app.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.tarektv.app.TarekTvApp
import com.tarektv.app.databinding.ActivitySearchBinding
import com.tarektv.app.player.PinManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class SearchActivity:AppCompatActivity(){
    private lateinit var b:ActivitySearchBinding;private val app get()=application as TarekTvApp;private lateinit var adapter:MediaAdapter;private var job:Job?=null;private var sourceId=-1L
    override fun onCreate(s:Bundle?){
        super.onCreate(s);b=ActivitySearchBinding.inflate(layoutInflater);setContentView(b.root);adapter=MediaAdapter({m->
            PinManager.runProtected(this,m.sourceId,app.repository.adultKey(m.type,m.id),m.name){
                val target=when(m.type){com.tarektv.app.data.model.MediaType.SERIES->SeriesDetailActivity::class.java;com.tarektv.app.data.model.MediaType.MOVIE->MovieDetailActivity::class.java;else->PlayerActivity::class.java}
                startActivity(Intent(this,target).putExtra("mediaId",m.id).putExtra("sourceId",m.sourceId).putExtra("url",m.url).putExtra("title",m.name).putExtra("subtitle_url",m.subtitleUrl.orEmpty()).putExtra("position",m.lastPositionMs).putExtra("type",m.type))
            }
        }){item,v->lifecycleScope.launch{app.repository.setFavorite(item.id,v)}};b.rv.layoutManager=GridLayoutManager(this,4);b.rv.adapter=adapter;b.back.setOnClickListener{finish()};
        lifecycleScope.launch{sourceId=app.repository.sources().first().firstOrNull{it.id==app.preferences.activeSourceId}?.id ?: app.repository.sources().first().firstOrNull()?.id ?: -1L}
        b.query.addTextChangedListener(object:android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,before:Int,count:Int){job?.cancel();job=lifecycleScope.launch{delay(250);val q=s?.toString()?.trim().orEmpty();if(sourceId!=-1L&&q.isNotBlank())adapter.submit(app.repository.search(sourceId,q))else adapter.submit(emptyList())}};override fun afterTextChanged(s:android.text.Editable?) {}})
    }
}
