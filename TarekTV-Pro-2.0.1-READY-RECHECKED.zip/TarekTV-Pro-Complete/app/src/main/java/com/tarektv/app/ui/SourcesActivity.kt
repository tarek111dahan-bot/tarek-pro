package com.tarektv.app.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.tarektv.app.TarekTvApp
import com.tarektv.app.data.model.SourceEntity
import com.tarektv.app.databinding.ActivitySourcesBinding
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class SourcesActivity : AppCompatActivity() {
    private lateinit var b: ActivitySourcesBinding
    private val app get() = application as TarekTvApp
    private lateinit var adapter: SourceAdapter

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        b = ActivitySourcesBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.rv.layoutManager = LinearLayoutManager(this)
        b.add.setOnClickListener { startActivity(Intent(this, AddSourceActivity::class.java)) }
        b.back.setOnClickListener { finish() }
        adapter = SourceAdapter({ source -> app.preferences.activeSourceId = source.id; adapter.setActive(source.id) }, { sync(it) }, { askDelete(it) }, { source, enabled -> lifecycleScope.launch { app.repository.setSourceEnabled(source.id, enabled) } })
        b.rv.adapter = adapter
        lifecycleScope.launch {
            app.repository.sources().collectLatest { sources ->
                adapter.submit(sources, app.preferences.activeSourceId)
                b.empty.text = if (sources.isEmpty()) "لا توجد مصادر. أضف M3U أو Xtream." else "مصادر المحتوى الخارجية"
            }
        }
    }

    private fun sync(source: SourceEntity) {
        lifecycleScope.launch {
            b.empty.text = "جاري مزامنة ${source.name}…"
            runCatching { app.repository.sync(source) }.onSuccess { Toast.makeText(this@SourcesActivity, "تمت مزامنة ${source.name}", Toast.LENGTH_SHORT).show() }.onFailure { Toast.makeText(this@SourcesActivity, "فشلت المزامنة: ${it.message}", Toast.LENGTH_LONG).show() }
        }
    }

    private fun askDelete(source: SourceEntity) {
        androidx.appcompat.app.AlertDialog.Builder(this).setTitle("حذف المصدر")
            .setMessage("سيتم حذف القنوات والمكتبة المخزنة لهذا المصدر.")
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("حذف") { _, _ -> lifecycleScope.launch { app.repository.deleteSource(source) } }
            .show()
    }
}
