package com.tarektv.app.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.tarektv.app.data.model.SourceEntity
import com.tarektv.app.data.model.SourceType
import com.tarektv.app.databinding.ItemSourceBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SourceAdapter(
    private val setActive: (SourceEntity) -> Unit,
    private val sync: (SourceEntity) -> Unit,
    private val delete: (SourceEntity) -> Unit,
    private val setEnabled: (SourceEntity, Boolean) -> Unit
) : RecyclerView.Adapter<SourceAdapter.VH>() {
    private var items = emptyList<SourceEntity>()
    private var activeId = -1L

    fun submit(list: List<SourceEntity>, activeId: Long) {
        items = list
        this.activeId = activeId
        notifyDataSetChanged()
    }

    fun setActive(id: Long) {
        activeId = id
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemSourceBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(items[position])

    inner class VH(private val b: ItemSourceBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(item: SourceEntity) {
            b.name.text = item.name
            b.kind.text = if (item.type == SourceType.XTREAM) "Xtream" else "M3U"
            b.url.text = item.url
            b.counts.text = "القنوات ${item.liveCount} · الأفلام ${item.movieCount} · المسلسلات ${item.seriesCount}"
            b.status.text = when {
                item.lastSyncError != null -> "آخر خطأ: ${item.lastSyncError}"
                item.lastSync != null -> "آخر مزامنة: ${SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(item.lastSync))}"
                else -> "لم تتم المزامنة بعد"
            }
            b.active.text = if (item.id == activeId) "المصدر النشط" else "تفعيل"
            b.enabled.setOnCheckedChangeListener(null)
            b.enabled.isChecked = item.enabled
            b.enabled.setOnCheckedChangeListener { _, checked ->
                if (checked != item.enabled) setEnabled(item, checked)
            }
            b.active.setOnClickListener { setActive(item) }
            b.sync.setOnClickListener { sync(item) }
            b.delete.setOnClickListener { delete(item) }
        }
    }
}
