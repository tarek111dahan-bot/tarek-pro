package com.tarektv.app.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.tarektv.app.TarekTvApp
import com.tarektv.app.data.model.MediaType
import com.tarektv.app.databinding.ActivitySectionSearchBinding
import com.tarektv.app.player.PinManager
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class HistoryActivity : AppCompatActivity() {
    private lateinit var b: ActivitySectionSearchBinding
    private val app get() = application as TarekTvApp
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivitySectionSearchBinding.inflate(layoutInflater); setContentView(b.root)
        b.title.text = "متابعة المشاهدة"; b.back.setOnClickListener { finish() }
        val adapter = MediaAdapter({ m -> PinManager.runProtected(this, m.sourceId, app.repository.adultKey(m.type, m.id), m.name) { startActivity(Intent(this, PlayerActivity::class.java).putExtra("mediaId", m.id).putExtra("sourceId", m.sourceId).putExtra("url", m.url).putExtra("title", m.name).putExtra("position", m.lastPositionMs).putExtra("type", m.type)) } })
        b.rv.layoutManager = GridLayoutManager(this, 5); b.rv.adapter = adapter
        lifecycleScope.launch {
            val source = app.repository.sources().first().firstOrNull { it.id == app.preferences.activeSourceId } ?: app.repository.sources().first().firstOrNull()
            if (source == null) { b.empty.text = "أضف مصدراً أولاً"; return@launch }
            val results = (listOf(MediaType.MOVIE, MediaType.SERIES, MediaType.EPISODE).flatMap { app.repository.sourceHistory(source.id, it).first() }).sortedByDescending { it.lastWatched }.take(100)
            adapter.submit(results); b.empty.text = if (results.isEmpty()) "لا يوجد محتوى تمت مشاهدته بعد" else ""
        }
    }
}
