package com.tarektv.app.data.util

import com.google.gson.GsonBuilder
import com.google.gson.reflect.TypeToken
import com.tarektv.app.data.model.SourceEntity

object SourceBackup {
    private val gson = GsonBuilder().setPrettyPrinting().create()

    fun export(sources: List<SourceEntity>): String = gson.toJson(sources.map { BackupSource.from(it) })

    fun importSources(json: String): List<SourceEntity> {
        val type = object : TypeToken<List<BackupSource>>() {}.type
        val values: List<BackupSource> = gson.fromJson(json, type) ?: emptyList()
        return values.filter { it.name.isNotBlank() && it.url.isNotBlank() }.map {
            SourceEntity(
                name = it.name.trim(),
                type = it.type,
                url = it.url.trim(),
                username = it.username?.trim()?.ifBlank { null },
                password = it.password,
                epgUrl = it.epgUrl?.trim()?.ifBlank { null },
                enabled = it.enabled
            )
        }
    }

    private data class BackupSource(
        val name: String,
        val type: String,
        val url: String,
        val username: String?,
        val password: String?,
        val epgUrl: String?,
        val enabled: Boolean
    ) {
        companion object {
            fun from(source: SourceEntity) = BackupSource(source.name, source.type, source.url, source.username, source.password, source.epgUrl, source.enabled)
        }
    }
}
