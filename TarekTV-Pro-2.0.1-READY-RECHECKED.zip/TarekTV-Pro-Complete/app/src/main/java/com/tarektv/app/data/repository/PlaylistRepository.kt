package com.tarektv.app.data.repository

import android.content.Context
import androidx.room.withTransaction
import com.tarektv.app.data.db.TarekDatabase
import com.tarektv.app.data.model.*
import com.tarektv.app.data.parser.EpgParser
import com.tarektv.app.data.parser.M3uParser
import com.tarektv.app.data.remote.XtreamClient
import com.tarektv.app.data.util.TextNormalizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.security.MessageDigest
import kotlin.math.abs

class PlaylistRepository(private val context: Context, private val db: TarekDatabase, private val prefs: Preferences) {
    private val sourceDao = db.sourceDao()
    private val groupDao = db.groupDao()
    private val mediaDao = db.mediaDao()
    private val epgDao = db.epgDao()
    private val m3u = M3uParser()
    private val epg = EpgParser()

    fun sources(): Flow<List<SourceEntity>> = sourceDao.observeAll()
    fun media(sourceId: Long, type: String): Flow<List<MediaEntity>> = mediaDao.observe(sourceId, type)
    fun mediaByGroup(sourceId: Long, type: String, groupId: Long): Flow<List<MediaEntity>> = mediaDao.observeByGroup(sourceId, type, groupId)
    fun episodes(sourceId: Long, seriesId: Long): Flow<List<MediaEntity>> = mediaDao.observeEpisodes(sourceId, MediaType.EPISODE, seriesId)
    fun groups(sourceId: Long, type: String): Flow<List<GroupEntity>> = groupDao.observe(sourceId, type)
    fun favorites(): Flow<List<MediaEntity>> = mediaDao.observeFavorites()
    fun sourceHistory(sourceId: Long, type: String): Flow<List<MediaEntity>> = mediaDao.observeHistory(sourceId, type)
    suspend fun currentEpg(sourceId: Long, channelRemoteId: String, now: Long = System.currentTimeMillis()) = epgDao.current(sourceId, channelRemoteId, now)
    suspend fun addSource(source: SourceEntity): Long = sourceDao.insert(source)
    suspend fun getMedia(id: Long): MediaEntity? = mediaDao.getById(id)
    suspend fun liveChannels(sourceId: Long): List<MediaEntity> = mediaDao.getLiveChannels(sourceId)
    suspend fun search(sourceId: Long, query: String): List<MediaEntity> = mediaDao.search(sourceId, query)

    suspend fun searchAll(query: String, type: String? = null): List<MediaEntity> = withContext(Dispatchers.IO) {
        val enabled = sourceDao.getEnabled()
        val raw = enabled.flatMap { source ->
            if (type.isNullOrBlank()) mediaDao.search(source.id, query) else mediaDao.searchByTerm(source.id, type, query)
        }
        raw.distinctBy { "${it.sourceId}|${it.remoteId}|${it.type}" }.sortedBy { it.name.lowercase() }.take(300)
    }

    suspend fun searchKeywords(keywords: List<String>, type: String? = null): List<MediaEntity> = withContext(Dispatchers.IO) {
        val terms = keywords.map(TextNormalizer::normalize).filter { it.isNotBlank() }.distinct()
        if (terms.isEmpty()) return@withContext emptyList()
        val all = sourceDao.getEnabled().flatMap { source ->
            if (type.isNullOrBlank()) {
                listOf(MediaType.LIVE, MediaType.MOVIE, MediaType.SERIES).flatMap { mediaDao.getAll(source.id, it) }
            } else mediaDao.getAll(source.id, type)
        }
        all.filter { item ->
            val haystack = listOf(item.name, item.description.orEmpty(), item.actors.orEmpty()).joinToString(" ")
            TextNormalizer.containsAny(haystack, terms)
        }.distinctBy { "${it.sourceId}|${it.remoteId}|${it.type}" }.sortedBy { it.name.lowercase() }.take(300)
    }
    suspend fun searchSection(sourceId: Long, type: String, query: String): List<MediaEntity> = mediaDao.searchByTerm(sourceId, type, query)
    suspend fun setFavorite(id: Long, value: Boolean) = mediaDao.setFavorite(id, value)
    suspend fun savePosition(id: Long, position: Long, duration: Long) = mediaDao.savePosition(id, position, duration)
    suspend fun markWatched(id: Long, position: Long, duration: Long) = mediaDao.markWatched(id, System.currentTimeMillis(), position, duration)
    suspend fun isProtected(sourceId: Long, key: String) = db.protectedDao().isProtected(sourceId, key)
    suspend fun setProtected(sourceId: Long, key: String, label: String) = db.protectedDao().upsert(ProtectedRuleEntity(sourceId = sourceId, ruleKey = key, label = label))
    suspend fun unprotect(sourceId: Long, key: String) = db.protectedDao().remove(sourceId, key)
    suspend fun setSourceEnabled(id: Long, enabled: Boolean) = sourceDao.setEnabled(id, enabled)

    suspend fun deleteSource(source: SourceEntity) {
        db.withTransaction {
            listOf(MediaType.LIVE, MediaType.MOVIE, MediaType.SERIES, MediaType.EPISODE).forEach { mediaDao.deleteAll(source.id, it) }
            listOf(MediaType.LIVE, MediaType.MOVIE, MediaType.SERIES).forEach { groupDao.deleteAll(source.id, it) }
            epgDao.deleteSource(source.id)
            sourceDao.delete(source)
            if (prefs.activeSourceId == source.id) prefs.activeSourceId = -1
        }
    }

    suspend fun syncAll(): List<String> = withContext(Dispatchers.IO) {
        sourceDao.getEnabled().mapNotNull { src ->
            try { sync(src); null } catch (error: Throwable) {
                val message = error.message ?: "Sync failed"
                sourceDao.markError(src.id, message.take(500))
                "${src.name}: $message"
            }
        }
    }

    suspend fun sync(source: SourceEntity) = withContext(Dispatchers.IO) {
        when (source.type) {
            SourceType.M3U -> syncM3u(source)
            SourceType.XTREAM -> syncXtream(source)
            else -> error("Unsupported source type: ${source.type}")
        }
        source.epgUrl?.takeIf { it.isNotBlank() }?.let { runCatching { syncEpg(source, it) } }
    }

    private suspend fun syncM3u(source: SourceEntity) {
        val items = m3u.parse(source.url)
        if (items.isEmpty()) error("Playlist is empty")
        val groups = items.groupBy { it.type to it.group?.trim().orEmpty() }
            .filterKeys { it.second.isNotBlank() }
            .map { (key, list) ->
                val (type, name) = key
                GroupEntity(stable(source.id, type, "GROUP:$name"), source.id, type, name, name, list.size)
            }
        val incoming = items.map { item ->
            val remote = item.tvgId?.ifBlank { null } ?: item.url
            val group = item.group?.trim()?.takeIf { it.isNotBlank() }
            val gid = group?.let { stable(source.id, item.type, "GROUP:$it") }
            MediaEntity(
                id = stable(source.id, item.type, remote),
                sourceId = source.id,
                type = item.type,
                remoteId = remote,
                groupId = gid,
                name = item.name,
                url = item.url,
                logo = item.logo,
                subtitleUrl = item.subtitleUrl,
                epgChannelId = item.tvgId,
                adult = item.adult
            )
        }
        storeSynced(source, incoming, groups)
        incoming.filter { it.adult }.forEach { setProtected(source.id, "MEDIA:${it.type}:${it.id}", it.name) }
        groups.filter { isAdult(it.name) }.forEach { setProtected(source.id, "GROUP:${it.type}:${it.id}", it.name) }
    }

    private suspend fun syncXtream(source: SourceEntity) {
        val user = source.username?.trim().orEmpty()
        val pass = source.password?.trim().orEmpty()
        require(user.isNotBlank() && pass.isNotBlank()) { "Xtream credentials are required" }
        val client = XtreamClient(source.url)
        val auth = client.api.auth(user, pass)
        require(auth.user_info?.auth == 1 || auth.user_info?.status?.equals("Active", true) == true) { "Xtream authentication failed" }
        val liveCategories = client.api.liveCategories(user, pass)
        val live = client.api.liveStreams(user, pass)
        val vodCategories = client.api.vodCategories(user, pass)
        val vod = client.api.vodStreams(user, pass)
        val seriesCategories = client.api.seriesCategories(user, pass)
        val series = client.api.series(user, pass)

        val groups = buildList {
            liveCategories.forEach { c -> c.category_id?.let { id -> add(GroupEntity(stable(source.id, MediaType.LIVE, "GROUP:$id"), source.id, MediaType.LIVE, id, c.category_name ?: id)) } }
            vodCategories.forEach { c -> c.category_id?.let { id -> add(GroupEntity(stable(source.id, MediaType.MOVIE, "GROUP:$id"), source.id, MediaType.MOVIE, id, c.category_name ?: id)) } }
            seriesCategories.forEach { c -> c.category_id?.let { id -> add(GroupEntity(stable(source.id, MediaType.SERIES, "GROUP:$id"), source.id, MediaType.SERIES, id, c.category_name ?: id)) } }
        }
        val liveItems = live.mapNotNull { v ->
            val id = v.stream_id?.toString() ?: return@mapNotNull null
            val gid = v.category_id?.let { stable(source.id, MediaType.LIVE, "GROUP:$it") }
            MediaEntity(
                id = stable(source.id, MediaType.LIVE, id), sourceId = source.id, type = MediaType.LIVE, remoteId = id,
                groupId = gid, name = v.name ?: id, url = client.url(MediaType.LIVE, id, user, pass, "ts"),
                logo = v.stream_icon, epgChannelId = v.epg_channel_id, adult = isAdult(v.name.orEmpty())
            )
        }
        val movieItems = vod.mapNotNull { v ->
            val id = v.stream_id?.toString() ?: return@mapNotNull null
            val gid = v.category_id?.let { stable(source.id, MediaType.MOVIE, "GROUP:$it") }
            MediaEntity(
                id = stable(source.id, MediaType.MOVIE, id), sourceId = source.id, type = MediaType.MOVIE, remoteId = id,
                groupId = gid, name = v.name ?: id,
                url = client.url(MediaType.MOVIE, id, user, pass, v.container_extension ?: "mp4"),
                logo = v.stream_icon, description = v.plot, year = v.releasedate?.take(4)?.toIntOrNull(),
                actors = v.cast, adult = isAdult(v.name.orEmpty())
            )
        }
        val seriesItems = series.mapNotNull { v ->
            val id = v.series_id?.toString() ?: return@mapNotNull null
            val gid = v.category_id?.let { stable(source.id, MediaType.SERIES, "GROUP:$it") }
            MediaEntity(
                id = stable(source.id, MediaType.SERIES, id), sourceId = source.id, type = MediaType.SERIES, remoteId = id,
                groupId = gid, name = v.name ?: id,
                url = client.url(MediaType.SERIES, id, user, pass, "mp4"),
                logo = v.cover, description = v.plot, year = v.releaseDate?.take(4)?.toIntOrNull(),
                actors = v.cast, adult = isAdult(v.name.orEmpty())
            )
        }
        val incoming = liveItems + movieItems + seriesItems
        storeSynced(source, incoming, groups)
        incoming.filter { it.adult }.forEach { setProtected(source.id, "MEDIA:${it.type}:${it.id}", it.name) }
        groups.filter { isAdult(it.name) }.forEach { setProtected(source.id, "GROUP:${it.type}:${it.id}", it.name) }
    }

    private suspend fun storeSynced(source: SourceEntity, incoming: List<MediaEntity>, groups: List<GroupEntity>) {
        if (incoming.isEmpty()) error("Source returned no playable items")
        db.withTransaction {
            val existing = listOf(MediaType.LIVE, MediaType.MOVIE, MediaType.SERIES, MediaType.EPISODE)
                .associateWith { type -> mediaDao.getAll(source.id, type).associateBy { it.remoteId } }
            listOf(MediaType.LIVE, MediaType.MOVIE, MediaType.SERIES).forEach { type ->
                val list = incoming.filter { it.type == type }.map { fresh ->
                    existing[type]?.get(fresh.remoteId)?.let { old ->
                        fresh.copy(
                            isFavorite = old.isFavorite,
                            lastWatched = old.lastWatched,
                            watchCount = old.watchCount,
                            lastPositionMs = old.lastPositionMs,
                            durationMs = old.durationMs,
                            actors = fresh.actors ?: old.actors,
                            subtitleUrl = fresh.subtitleUrl ?: old.subtitleUrl,
                            epgChannelId = fresh.epgChannelId ?: old.epgChannelId
                        )
                    } ?: fresh
                }
                if (list.isNotEmpty()) {
                    mediaDao.deleteAll(source.id, type)
                    mediaDao.upsertAll(list)
                }
            }
            listOf(MediaType.LIVE, MediaType.MOVIE, MediaType.SERIES).forEach { groupDao.deleteAll(source.id, it) }
            groupDao.upsertAll(groups)
            mediaDao.deleteOrphanEpisodes(source.id)
            sourceDao.markSuccess(
                source.id, System.currentTimeMillis(), incoming.count { it.type == MediaType.LIVE },
                incoming.count { it.type == MediaType.MOVIE }, incoming.count { it.type == MediaType.SERIES }
            )
        }
    }

    private suspend fun syncEpg(source: SourceEntity, url: String) {
        val text = epg.download(url)
        val programs = epg.parse(text).map { it.copy(sourceId = source.id, id = stable(source.id, "EPG", "${it.channelRemoteId}|${it.startMs}|${it.title}")) }
        if (programs.isEmpty()) return
        db.withTransaction { epgDao.deleteSource(source.id); epgDao.upsertAll(programs) }
    }

    suspend fun loadSeriesEpisodes(sourceId: Long, seriesId: Long) {
        val source = sourceDao.get(sourceId) ?: return
        if (source.type != SourceType.XTREAM) return
        val series = mediaDao.getById(seriesId) ?: return
        val user = source.username.orEmpty()
        val pass = source.password.orEmpty()
        val client = XtreamClient(source.url)
        val info = client.api.seriesInfo(user, pass, series.remoteId)
        val incoming = info.episodes.orEmpty().flatMap { (seasonKey, episodes) ->
            episodes.mapNotNull { e ->
                val id = (e["id"]?.toString() ?: e["episode_id"]?.toString())?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
                val season = e["season"]?.toString()?.toDoubleOrNull()?.toInt() ?: seasonKey.toDoubleOrNull()?.toInt() ?: 0
                val number = e["episode_num"]?.toString()?.toDoubleOrNull()?.toInt() ?: 0
                val title = e["title"]?.toString().orEmpty().ifBlank { "الحلقة $number" }
                val ext = e["container_extension"]?.toString().orEmpty().ifBlank { "mp4" }
                val stream = client.url("SERIES", id, user, pass, ext)
                MediaEntity(
                    id = stable(sourceId, MediaType.EPISODE, "${series.remoteId}:$id"),
                    sourceId = sourceId, type = MediaType.EPISODE, remoteId = id, groupId = series.id,
                    name = title, url = stream, logo = e["movie_image"]?.toString() ?: series.logo,
                    season = season, episode = number, adult = series.adult,
                    actors = series.actors
                )
            }
        }
        if (incoming.isNotEmpty()) {
            db.withTransaction {
                mediaDao.deleteGroup(sourceId, MediaType.EPISODE, series.id)
                mediaDao.upsertAll(incoming)
            }
        }
    }

    suspend fun sourceSnapshot(): List<SourceEntity> = withContext(Dispatchers.IO) { sourceDao.getEnabled() }

    suspend fun syncSource(id: Long) = withContext(Dispatchers.IO) {
        val source = sourceDao.get(id) ?: error("Source not found")
        sync(source)
    }

    fun adultKey(type: String, id: Long) = "MEDIA:$type:$id"
    private fun isAdult(value: String): Boolean {
        val v = value.lowercase()
        return listOf("xxx", "adult", "18+", "porn", "sex", "إباح", "بالغ").any(v::contains)
    }

    private fun stable(source: Long, type: String, key: String): Long {
        val hash = MessageDigest.getInstance("SHA-256").digest("$source|$type|$key".toByteArray())
        var value = 0L
        for (i in 0 until 8) value = (value shl 8) or (hash[i].toLong() and 255)
        return abs(if (value == Long.MIN_VALUE) Long.MAX_VALUE else value).coerceAtLeast(1)
    }
}
