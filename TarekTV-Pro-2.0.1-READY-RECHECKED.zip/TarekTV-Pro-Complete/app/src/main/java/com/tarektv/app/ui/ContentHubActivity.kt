package com.tarektv.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.tarektv.app.R
import com.tarektv.app.data.catalog.SectionCatalog
import com.tarektv.app.data.model.MediaType

class ContentHubActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_content_hub)
        findViewById<View>(R.id.back).setOnClickListener { finish() }
        findViewById<View>(R.id.live).setOnClickListener { openType(MediaType.LIVE) }
        findViewById<View>(R.id.movies).setOnClickListener { openType(MediaType.MOVIE) }
        findViewById<View>(R.id.series).setOnClickListener { openType(MediaType.SERIES) }
        findViewById<View>(R.id.sports).setOnClickListener { openKeywords(SectionCatalog.SPORTS) }
        findViewById<View>(R.id.movieChannels).setOnClickListener { openKeywords(SectionCatalog.MOVIE_CHANNELS) }
        findViewById<View>(R.id.netflix).setOnClickListener { openKeywords(SectionCatalog.NETFLIX) }
        findViewById<View>(R.id.shahid).setOnClickListener { openKeywords(SectionCatalog.SHAHID) }
        findViewById<View>(R.id.bean).setOnClickListener { openKeywords(SectionCatalog.BEAN) }
        findViewById<View>(R.id.islamic).setOnClickListener { startActivity(Intent(this, IslamicActivity::class.java)) }
        findViewById<View>(R.id.favorites).setOnClickListener { startActivity(Intent(this, LibraryActivity::class.java).putExtra("mode", "favorites")) }
        findViewById<View>(R.id.history).setOnClickListener { startActivity(Intent(this, HistoryActivity::class.java)) }
        findViewById<View>(R.id.epg).setOnClickListener { startActivity(Intent(this, EpgActivity::class.java)) }
        findViewById<View>(R.id.sources).setOnClickListener { startActivity(Intent(this, SourcesActivity::class.java)) }
        findViewById<View>(R.id.settings).setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
    }

    private fun openType(type: String) {
        startActivity(Intent(this, LibraryActivity::class.java).putExtra("type", type))
    }

    private fun openKeywords(id: String) {
        val section = SectionCatalog.byId(id) ?: return
        startActivity(Intent(this, SectionSearchActivity::class.java)
            .putExtra("term", section.title)
            .putExtra("keywords", section.keywords.toTypedArray())
            .putExtra("sectionType", section.mediaType.orEmpty()))
    }
}
