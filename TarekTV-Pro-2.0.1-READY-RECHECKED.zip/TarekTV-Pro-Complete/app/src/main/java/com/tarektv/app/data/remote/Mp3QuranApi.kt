package com.tarektv.app.data.remote

import retrofit2.http.GET
import retrofit2.http.Query

interface Mp3QuranApi {
    @GET("api/v3/reciters")
    suspend fun reciters(@Query("language") language: String = "ar"): Mp3QuranReciters

    @GET("api/v3/suwar")
    suspend fun suwar(@Query("language") language: String = "ar"): Mp3QuranSuwar
}

data class Mp3QuranReciters(val reciters: List<Mp3QuranReciter> = emptyList())
data class Mp3QuranReciter(val id: Int? = null, val name: String? = null, val letter: String? = null, val moshaf: List<Mp3QuranMoshaf> = emptyList())
data class Mp3QuranMoshaf(
    val id: Int? = null,
    val name: String? = null,
    val server: String? = null,
    val surah_total: Int? = null,
    val moshaf_type: Int? = null,
    val surah_list: String? = null
)
data class Mp3QuranSuwar(val suwar: List<Mp3QuranSura> = emptyList())
data class Mp3QuranSura(val id: Int? = null, val name: String? = null)
