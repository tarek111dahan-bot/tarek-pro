package com.tarektv.app.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.tarektv.app.TarekTvApp
import com.tarektv.app.databinding.ActivitySettingsBinding

class SettingsActivity:AppCompatActivity(){
    private lateinit var b:ActivitySettingsBinding;private val app get()=application as TarekTvApp
    override fun onCreate(s:Bundle?){super.onCreate(s);b=ActivitySettingsBinding.inflate(layoutInflater);setContentView(b.root);b.back.setOnClickListener{finish()};b.parental.isChecked=app.preferences.parentalLock;b.syncOnLaunch.isChecked=app.preferences.syncOnLaunch;b.pin.setText(app.preferences.pin);b.externalPlayer.setText(app.preferences.externalPlayerPackage ?: "");b.save.setOnClickListener{app.preferences.parentalLock=b.parental.isChecked;app.preferences.syncOnLaunch=b.syncOnLaunch.isChecked;app.preferences.pin=b.pin.text.toString().ifBlank{"4827"};app.preferences.externalPlayerPackage=b.externalPlayer.text.toString().trim().ifBlank{null};Toast.makeText(this,"تم حفظ الإعدادات",Toast.LENGTH_SHORT).show()}}
}
