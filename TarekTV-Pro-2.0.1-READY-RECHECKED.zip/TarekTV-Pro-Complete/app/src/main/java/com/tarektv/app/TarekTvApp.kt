package com.tarektv.app

import android.app.Application
import com.tarektv.app.data.db.TarekDatabase
import com.tarektv.app.data.repository.PlaylistRepository
import com.tarektv.app.data.repository.Preferences

class TarekTvApp : Application() {
    val database by lazy { TarekDatabase.getInstance(this) }
    val preferences by lazy { Preferences(this) }
    val repository by lazy { PlaylistRepository(this, database, preferences) }

    override fun onCreate() {
        super.onCreate()
        SyncBootstrap.schedule(this)
    }
}
