package com.tarektv.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.tarektv.app.R
import com.tarektv.app.TarekTvApp
import com.tarektv.app.data.model.MediaEntity
import com.tarektv.app.databinding.ActivityMovieDetailBinding
import com.tarektv.app.player.PinManager
import kotlinx.coroutines.launch

class MovieDetailActivity : AppCompatActivity() {
    private lateinit var b: ActivityMovieDetailBinding
    private val app get() = application as TarekTvApp
    private var item: MediaEntity? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMovieDetailBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.back.setOnClickListener { finish() }
        lifecycleScope.launch {
            item = app.repository.getMedia(intent.getLongExtra("mediaId", -1))
            render(item)
        }
    }

    private fun render(m: MediaEntity?) {
        if (m == null) { b.title.text = "لم يتم العثور على المحتوى"; return }
        b.title.text = m.name
        b.year.text = m.year?.toString().orEmpty()
        b.description.text = m.description?.takeIf { it.isNotBlank() } ?: "لا يوجد وصف من المصدر."
        Glide.with(this).load(m.logo).placeholder(R.drawable.ic_placeholder).error(R.drawable.ic_placeholder).into(b.poster)
        val actors = m.actors.orEmpty().split(',', '|', ';').map { it.trim() }.filter { it.isNotBlank() }.distinct().take(20)
        b.actorContainer.removeAllViews()
        actors.forEach { actor ->
            val button = Button(this).apply { text = actor; isAllCaps = false; setOnClickListener { startActivity(Intent(this@MovieDetailActivity, ActorActivity::class.java).putExtra("actor", actor).putExtra("sourceId", m.sourceId)) } }
            b.actorContainer.addView(button, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        b.play.setOnClickListener {
            PinManager.runProtected(this, m.sourceId, app.repository.adultKey(m.type, m.id), m.name) {
                startActivity(Intent(this, PlayerActivity::class.java).putExtra("mediaId", m.id).putExtra("sourceId", m.sourceId).putExtra("url", m.url).putExtra("title", m.name).putExtra("subtitle_url", m.subtitleUrl.orEmpty()).putExtra("position", m.lastPositionMs).putExtra("type", m.type))
            }
        }
    }
}
