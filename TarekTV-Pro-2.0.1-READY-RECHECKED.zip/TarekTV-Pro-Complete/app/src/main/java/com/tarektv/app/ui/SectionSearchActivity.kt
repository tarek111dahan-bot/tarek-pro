package com.tarektv.app.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.tarektv.app.TarekTvApp
import com.tarektv.app.data.model.MediaType
import com.tarektv.app.databinding.ActivitySectionSearchBinding
import com.tarektv.app.player.PinManager
import kotlinx.coroutines.launch

class SectionSearchActivity : AppCompatActivity() {
    private lateinit var b: ActivitySectionSearchBinding
    private val app get() = application as TarekTvApp
    private lateinit var adapter: MediaAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivitySectionSearchBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.back.setOnClickListener { finish() }
        val term = intent.getStringExtra("term").orEmpty()
        val keywords = intent.getStringArrayExtra("keywords")?.toList().orEmpty().ifEmpty { listOf(term) }
        val requestedType = intent.getStringExtra("sectionType")?.takeIf { it.isNotBlank() }
        b.title.text = term
        adapter = MediaAdapter({ open(it) }) { item, value -> lifecycleScope.launch { app.repository.setFavorite(item.id, value) } }
        b.rv.layoutManager = GridLayoutManager(this, 5)
        b.rv.adapter = adapter
        lifecycleScope.launch {
            val results = app.repository.searchKeywords(keywords, requestedType)
            adapter.submit(results)
            b.empty.text = when {
                results.isNotEmpty() -> "${results.size} نتيجة من المصادر المتاحة"
                else -> "لا توجد نتائج مطابقة في المصادر الحالية"
            }
        }
    }

    private fun open(item: com.tarektv.app.data.model.MediaEntity) {
        PinManager.runProtected(this, item.sourceId, app.repository.adultKey(item.type, item.id), item.name) {
            val target = when (item.type) {
                MediaType.SERIES -> SeriesDetailActivity::class.java
                MediaType.MOVIE -> MovieDetailActivity::class.java
                else -> PlayerActivity::class.java
            }
            startActivity(Intent(this, target).putExtra("mediaId", item.id).putExtra("sourceId", item.sourceId)
                .putExtra("url", item.url).putExtra("title", item.name).putExtra("subtitle_url", item.subtitleUrl.orEmpty())
                .putExtra("position", item.lastPositionMs).putExtra("type", item.type))
        }
    }
}
