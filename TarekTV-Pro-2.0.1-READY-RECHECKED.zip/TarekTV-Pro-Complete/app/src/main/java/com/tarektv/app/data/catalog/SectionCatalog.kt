package com.tarektv.app.data.catalog

import com.tarektv.app.data.model.MediaType

data class ContentSection(
    val id: String,
    val title: String,
    val subtitle: String,
    val mediaType: String? = null,
    val keywords: List<String> = emptyList(),
    val requiresSource: Boolean = true
)

object SectionCatalog {
    const val LIVE = "live"
    const val MOVIES = "movies"
    const val SERIES = "series"
    const val SPORTS = "sports"
    const val MOVIE_CHANNELS = "movie_channels"
    const val NETFLIX = "netflix"
    const val SHAHID = "shahid"
    const val BEAN = "bean"
    const val ISLAMIC = "islamic"
    const val FAVORITES = "favorites"
    const val HISTORY = "history"
    const val EPG = "epg"

    val all: List<ContentSection> = listOf(
        ContentSection(LIVE, "البث المباشر", "القنوات المباشرة من المصادر", MediaType.LIVE),
        ContentSection(MOVIES, "الأفلام", "أفلام VOD من المصادر", MediaType.MOVIE),
        ContentSection(SERIES, "المسلسلات", "المسلسلات والحلقات", MediaType.SERIES),
        ContentSection(SPORTS, "الرياضة", "القنوات والمجموعات الرياضية", keywords = listOf("رياضة", "sports", "sport", "beinsports", "ssc", "الكأس", "alkass")),
        ContentSection(MOVIE_CHANNELS, "قنوات الأفلام", "قنوات السينما والأفلام", mediaType = MediaType.LIVE, keywords = listOf("movie", "movies", "cinema", "film", "أفلام", "سينما")),
        ContentSection(NETFLIX, "Netflix", "محتوى يحمل وسم Netflix في المصدر", keywords = listOf("netflix")),
        ContentSection(SHAHID, "Shahid", "محتوى يحمل وسم Shahid في المصدر", keywords = listOf("shahid", "شاهد")),
        ContentSection(BEAN, "Bean Movies", "محتوى يحمل وسم Bean Movies في المصدر", keywords = listOf("bean movies", "beanmovie", "bean")),
        ContentSection(ISLAMIC, "المكتبة الإسلامية", "قرآن كريم وتلاوات مباشرة من MP3Quran", requiresSource = false),
        ContentSection(FAVORITES, "المفضلة", "المحتوى الذي حفظته", requiresSource = false),
        ContentSection(HISTORY, "المشاهدة الأخيرة", "المحتوى الذي بدأت مشاهدته", requiresSource = false),
        ContentSection(EPG, "دليل البرامج EPG", "البرنامج الحالي والقادم", requiresSource = true)
    )

    fun byId(id: String): ContentSection? = all.firstOrNull { it.id == id }
}
