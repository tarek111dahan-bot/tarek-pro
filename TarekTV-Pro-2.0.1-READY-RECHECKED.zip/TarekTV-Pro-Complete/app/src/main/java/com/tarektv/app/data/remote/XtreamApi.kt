package com.tarektv.app.data.remote

import retrofit2.http.GET
import retrofit2.http.Query

interface XtreamApi {
    @GET("player_api.php") suspend fun auth(@Query("username") u: String, @Query("password") p: String): XtreamAuth
    @GET("player_api.php") suspend fun liveCategories(@Query("username") u: String, @Query("password") p: String, @Query("action") action: String = "get_live_categories"): List<XtreamCategory>
    @GET("player_api.php") suspend fun liveStreams(@Query("username") u: String, @Query("password") p: String, @Query("action") action: String = "get_live_streams"): List<XtreamLive>
    @GET("player_api.php") suspend fun vodCategories(@Query("username") u: String, @Query("password") p: String, @Query("action") action: String = "get_vod_categories"): List<XtreamCategory>
    @GET("player_api.php") suspend fun vodStreams(@Query("username") u: String, @Query("password") p: String, @Query("action") action: String = "get_vod_streams"): List<XtreamVod>
    @GET("player_api.php") suspend fun seriesCategories(@Query("username") u: String, @Query("password") p: String, @Query("action") action: String = "get_series_categories"): List<XtreamCategory>
    @GET("player_api.php") suspend fun series(@Query("username") u: String, @Query("password") p: String, @Query("action") action: String = "get_series"): List<XtreamSeries>
    @GET("player_api.php") suspend fun seriesInfo(@Query("username") u: String, @Query("password") p: String, @Query("series_id") seriesId: String, @Query("action") action: String = "get_series_info"): XtreamSeriesInfo
}

data class XtreamAuth(val user_info: XtreamUserInfo?, val server_info: XtreamServerInfo?)
data class XtreamUserInfo(val auth: Int?, val status: String?, val exp_date: String?)
data class XtreamServerInfo(val url: String?, val port: String?, val https_port: String?, val server_protocol: String?, val rtmp_port: String?)
data class XtreamCategory(val category_id: String?, val category_name: String?)
data class XtreamLive(val stream_id: Int?, val name: String?, val stream_icon: String?, val category_id: String?, val epg_channel_id: String?, val tv_archive: Int?)
data class XtreamVod(val stream_id: Int?, val name: String?, val stream_icon: String?, val category_id: String?, val plot: String?, val releasedate: String?, val rating: String?, val container_extension: String?, val cast: String?, val director: String?, val genre: String?)
data class XtreamSeries(val series_id: Int?, val name: String?, val cover: String?, val category_id: String?, val plot: String?, val releaseDate: String?, val rating: String?, val cast: String?, val director: String?, val genre: String?)
data class XtreamSeriesInfo(val info: Map<String, Any>?, val seasons: List<Map<String, Any>>?, val episodes: Map<String, List<Map<String, Any>>>?)
