package com.tarektv.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.tarektv.app.TarekTvApp
import com.tarektv.app.data.model.MediaType
import com.tarektv.app.databinding.ActivityMainBinding
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private val app get() = application as TarekTvApp

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        wire()
        observe()
        if (app.preferences.syncOnLaunch) lifecycleScope.launch { app.repository.syncAll() }
    }

    private fun wire() {
        b.cardWatch.setOnClickListener { open(MediaType.LIVE) }
        b.cardLibrary.setOnClickListener { startActivity(Intent(this, ContentHubActivity::class.java)) }
        b.cardSettings.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        b.btnSearch.setOnClickListener { startActivity(Intent(this, SearchActivity::class.java)) }
        b.btnSync.setOnClickListener { syncNow() }
    }

    private fun observe() {
        lifecycleScope.launch {
            app.repository.sources().collect { src ->
                val active = src.firstOrNull { it.id == app.preferences.activeSourceId } ?: src.firstOrNull()
                b.txtSource.text = active?.name ?: "أضف مصدراً"
                b.txtStatus.text = if (active?.lastSync != null) {
                    "آخر مزامنة: ${java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date(active.lastSync))}"
                } else "لم تتم المزامنة بعد"
                b.btnSync.visibility = View.VISIBLE
            }
        }
    }

    private fun syncNow() {
        b.btnSync.isEnabled = false
        lifecycleScope.launch {
            Toast.makeText(this@MainActivity, "تتم مزامنة القنوات والمكتبات…", Toast.LENGTH_SHORT).show()
            val errors = app.repository.syncAll()
            b.btnSync.isEnabled = true
            Toast.makeText(
                this@MainActivity,
                if (errors.isEmpty()) "تمت المزامنة بنجاح" else errors.joinToString("\n"),
                if (errors.isEmpty()) Toast.LENGTH_SHORT else Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun open(type: String) {
        lifecycleScope.launch {
            val sources = app.repository.sources().first()
            val source = sources.firstOrNull { it.id == app.preferences.activeSourceId } ?: sources.firstOrNull()
            if (source == null) {
                startActivity(Intent(this@MainActivity, AddSourceActivity::class.java))
                return@launch
            }
            startActivity(Intent(this@MainActivity, LibraryActivity::class.java)
                .putExtra("type", type)
                .putExtra("sourceId", source.id))
        }
    }
}
