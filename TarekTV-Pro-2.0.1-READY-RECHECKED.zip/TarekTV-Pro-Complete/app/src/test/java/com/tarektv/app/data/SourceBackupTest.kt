package com.tarektv.app.data

import com.tarektv.app.data.model.SourceEntity
import com.tarektv.app.data.model.SourceType
import com.tarektv.app.data.util.SourceBackup
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SourceBackupTest {
    @Test fun roundTripKeepsConfigurationFields() {
        val input = listOf(SourceEntity(name = "Test", type = SourceType.XTREAM, url = "https://example.test", username = "u", password = "p", epgUrl = "https://example.test/epg.xml", enabled = false))
        val output = SourceBackup.importSources(SourceBackup.export(input))
        assertEquals(1, output.size)
        assertEquals("Test", output[0].name)
        assertEquals(SourceType.XTREAM, output[0].type)
        assertEquals("u", output[0].username)
        assertEquals("p", output[0].password)
        assertTrue(!output[0].enabled)
    }
}
