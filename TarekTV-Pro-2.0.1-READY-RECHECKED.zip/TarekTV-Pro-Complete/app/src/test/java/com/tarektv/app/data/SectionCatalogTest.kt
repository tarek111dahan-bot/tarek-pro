package com.tarektv.app.data

import com.tarektv.app.data.catalog.SectionCatalog
import com.tarektv.app.data.util.TextNormalizer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SectionCatalogTest {
    @Test fun containsAllRequestedSections() {
        val ids = SectionCatalog.all.map { it.id }
        assertTrue(ids.contains(SectionCatalog.LIVE))
        assertTrue(ids.contains(SectionCatalog.MOVIES))
        assertTrue(ids.contains(SectionCatalog.SERIES))
        assertTrue(ids.contains(SectionCatalog.NETFLIX))
        assertTrue(ids.contains(SectionCatalog.SHAHID))
        assertTrue(ids.contains(SectionCatalog.BEAN))
        assertTrue(ids.contains(SectionCatalog.ISLAMIC))
    }

    @Test fun arabicNormalizationIsStable() {
        assertEquals("اسلاميه", TextNormalizer.normalize("إِسْلَامِيَّة"))
    }
}
