package com.tarektv.app.data.parser

import com.tarektv.app.data.model.MediaType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class M3uParserTest {
    @Test
    fun parsesLiveAndMovieAndSubtitle() {
        val input = """#EXTM3U
#EXTINF:-1 tvg-id="news" tvg-logo="https://example.com/a.png" group-title="News",قناة الأخبار
https://example.com/live.m3u8
#EXTINF:-1 tvg-id="m1" group-title="Movies" subtitles="https://example.com/a.srt",فيلم 1
https://example.com/movie.mp4
"""
        val result = M3uParser().parseText(input)
        assertEquals(2, result.size)
        assertEquals(MediaType.LIVE, result[0].type)
        assertEquals(MediaType.MOVIE, result[1].type)
        assertEquals("https://example.com/a.srt", result[1].subtitleUrl)
        assertTrue(result[0].logo!!.contains("a.png"))
    }
}
