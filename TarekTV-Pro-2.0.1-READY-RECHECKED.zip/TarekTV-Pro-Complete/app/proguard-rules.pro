# Keep Retrofit/Gson model fields used by reflection.
-keepattributes Signature
-keepattributes *Annotation*
-keep class com.tarektv.app.data.remote.** { *; }
-keep class com.google.gson.** { *; }
-keep class androidx.media3.** { *; }
