# Source backup

The app's source records can be serialized as JSON by `SourceBackup`. The format is intended for private user backups.

Because Xtream passwords are part of a working source configuration, the exported JSON must be treated as sensitive and should not be published in a public repository.
