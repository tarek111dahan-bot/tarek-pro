# Release Checklist

Before publishing an APK produced by CI:

1. Confirm the workflow completes the Debug and unsigned Release builds.
2. Install Debug on the target Android TV and verify D-pad focus, channel up/down and Back navigation.
3. Add at least one authorized M3U or Xtream source and run sync.
4. Verify live playback, movie playback, series episode playback, subtitle file loading, favorites, resume, actor navigation, EPG and Islamic reciter playback.
5. Verify source failures leave the previously synchronized data available.
6. Check the APK SHA-256 recorded by CI before distribution.
