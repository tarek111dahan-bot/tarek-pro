# Tarek TV Pro — Build Status

This archive is the source project prepared for GitHub Actions.

## Included
- Android TV + phone UI with Arabic RTL.
- Exactly three primary home cards.
- M3U and Xtream playlist synchronization.
- Multiple independently stored sources with manual add/delete/enable flow.
- Safe synchronization that preserves favorites, watch history and resume positions for matching remote IDs.
- EPG/XMLTV parsing and current-program lookup.
- Internal Media3 player with HLS, DASH and common progressive media detection.
- Live channel switching from TV remote channel keys plus DPAD fallbacks.
- Remote/local subtitle support (SRT/VTT).
- Search across enabled sources and alias-aware content sections.
- Movies, series, episode loading, actor pages, favorites, history and resume playback.
- Islamic section backed by the MP3Quran API with multiple reciters and real audio playback.
- Chromecast integration.
- Background Media3 session service foundation for persistent media sessions.
- PIN/parental protection hooks.
- WorkManager automatic source synchronization.

## Static fixes in 2.0.1
- WorkManager pinned to 2.11.0 so the project remains minSdk 23; WorkManager 2.12.0 requires minSdk 24.
- Kotlin reserved-word declaration in SourceBackup renamed to `importSources`.
- Xtream series-info API parameter order fixed so `series_id` can be passed positionally without omitting a required argument.
- MainActivity now imports `MediaType` explicitly.

## Verification
- ZIP archive integrity is checked before delivery.
- Static source/layout/manifest checks are included in CI.
- Unit tests are included for the M3U parser, section catalog and text normalization.
- The supplied environment does not contain the Android SDK and Gradle dependency cache, so a local APK build is **not** claimed here.
- GitHub Actions is the authoritative compilation test for the delivered source.
