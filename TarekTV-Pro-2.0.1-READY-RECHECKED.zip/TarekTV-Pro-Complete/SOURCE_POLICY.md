# Source Policy

Tarek TV Pro is a client application. It stores source URLs entered by the user and retrieves the data exposed by those sources.

The project does not ship a hidden channel list, a forced update URL, or a bundled catalog of copyrighted movies/series.

Users are responsible for using M3U, Xtream, EPG and other media sources they are authorized to access.

The Islamic section uses the public MP3Quran API for reciter/surah metadata and playback URLs. See the project audit for the official API reference.
