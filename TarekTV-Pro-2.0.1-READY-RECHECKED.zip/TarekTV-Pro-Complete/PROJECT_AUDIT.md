# Tarek TV Pro — Project Audit

## Product scope implemented in source

The project is organized as a real Android application, not a ZIP containing another project. The root contains the Gradle settings and the `app` module.

### Home and navigation
- Arabic RTL Android TV and phone support.
- Exactly three primary cards on the home screen.
- Separate content hub with live TV, movies, series, sports, movie channels, Netflix, Shahid, Bean Movies, Islamic library, favorites, history, EPG, sources and settings.

### Sources and updates
- Multiple source records are stored independently.
- M3U parser supports standard EXTINF attributes including tvg-id, tvg-logo, group-title and subtitle attributes.
- Xtream supports authentication, live/VOD/series categories and streams, and series episode loading.
- WorkManager runs periodic synchronization when network is available.
- A failed/empty sync does not intentionally erase an existing populated type.
- Favorites, resume position and watch metadata are preserved when a source item keeps the same remote ID.

### Playback
- Media3/ExoPlayer internal player.
- HLS, DASH, TS, MP4, MKV and MP3 MIME detection.
- 720p/4.5 Mbps ceiling in track selection for the requested TV target.
- Remote channel switching remains inside the player.
- SRT/VTT remote subtitles and local document subtitles.
- Chromecast button and default media receiver support.
- MediaPlaybackService included for persistent media-session support.

### Library
- Movies and series detail screens.
- Actor/cast navigation into matching source content.
- Favorites and history.
- Resume position storage.
- Search over enabled sources with Arabic/text normalization and aliases.

### Islamic library
- MP3Quran API integration for reciters and surah lists.
- Actual audio URLs are constructed from the selected reciter server and surah IDs, then played through the internal Media3 player.
- API source documentation: https://www.mp3quran.net/ar/api/2

## Build truth

The environment used to prepare this archive does not include a usable Android SDK installation or cached Maven/Gradle dependencies. No APK was fabricated and no successful local Android compilation is claimed. The delivered source has also been re-checked for the known minSdk/work-runtime and Kotlin source-level blockers listed above.

GitHub Actions installs Java 17, Android SDK 35 and Gradle 8.11.1 and runs unit tests plus Debug/Release APK builds.
