package com.tarektv.pro;
import java.io.*;import java.net.*;import java.nio.charset.StandardCharsets;import java.util.*;
public final class M3uLoader {
 public static List<Channel> load(String source) throws IOException {
  InputStream in;
  if(source.startsWith("http://")||source.startsWith("https://")){ HttpURLConnection c=(HttpURLConnection)new URL(source).openConnection(); c.setConnectTimeout(15000); c.setReadTimeout(20000); c.setRequestProperty("User-Agent","TarekTV-Pro/1.0"); in=c.getInputStream(); }
  else throw new IOException("Only HTTP/HTTPS M3U sources are supported in this build");
  List<Channel> out=new ArrayList<>(); String name=null;
  try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){ String line; while((line=r.readLine())!=null){ line=line.trim(); if(line.startsWith("#EXTINF:")){ int comma=line.indexOf(','); name=comma>=0?line.substring(comma+1).trim():"Channel"; } else if(!line.isEmpty()&&!line.startsWith("#")&&name!=null){ out.add(new Channel(name,line)); name=null; } } }
  return out;
 }
}
