package com.tarektv.pro;
import android.app.*;import android.content.*;import android.os.*;import android.view.*;import android.widget.*;import java.util.*;import java.util.concurrent.*;
public class MainActivity extends Activity {
 private LinearLayout list; private TextView status; private EditText source;
 @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main); list=findViewById(R.id.channelList);status=findViewById(R.id.status);findViewById(R.id.addSource).setOnClickListener(v->showSourceDialog());findViewById(R.id.refresh).setOnClickListener(v->loadSource());}
 private void showSourceDialog(){ source=new EditText(this); source.setSingleLine(true);source.setHint("https://example.com/playlist.m3u"); new AlertDialog.Builder(this).setTitle("مصدر M3U").setView(source).setPositiveButton("حفظ وتحديث",(d,w)->loadSource(source.getText().toString().trim())).setNegativeButton("إلغاء",null).show(); }
 private void loadSource(){ if(source==null||source.getText().toString().trim().isEmpty()){showSourceDialog();return;} loadSource(source.getText().toString().trim()); }
 private void loadSource(String url){status.setText("جاري تحميل القنوات…");Executors.newSingleThreadExecutor().execute(()->{try{List<Channel> cs=M3uLoader.load(url);runOnUiThread(()->render(cs));}catch(Exception e){runOnUiThread(()->status.setText("تعذر تحميل المصدر: "+e.getMessage()));}});}
 private void render(List<Channel> cs){list.removeAllViews();status.setText("تم تحميل "+cs.size()+" قناة");for(Channel c:cs){Button b=new Button(this);b.setText(c.name);b.setTextSize(18);b.setAllCaps(false);b.setFocusable(true);b.setOnClickListener(v->{Intent i=new Intent(this,PlayerActivity.class);i.putExtra("url",c.url);i.putExtra("name",c.name);startActivity(i);});list.addView(b);}}
}
