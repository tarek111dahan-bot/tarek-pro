package com.tarektv.pro;
import android.app.*;import android.media.*;import android.os.*;import android.view.*;
public class PlayerActivity extends Activity {
 private MediaPlayer player;
 @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_player);SurfaceView s=findViewById(R.id.video);String url=getIntent().getStringExtra("url");player=new MediaPlayer();player.setAudioStreamType(android.media.AudioManager.STREAM_MUSIC);player.setDisplay(s.getHolder());try{player.setDataSource(url);player.setOnPreparedListener(MediaPlayer::start);player.setOnErrorListener((mp,w,e)->{finish();return true;});player.prepareAsync();}catch(Exception e){finish();}}
 @Override protected void onPause(){super.onPause();if(player!=null&&player.isPlaying())player.pause();}
 @Override protected void onDestroy(){if(player!=null){player.release();player=null;}super.onDestroy();}
}
