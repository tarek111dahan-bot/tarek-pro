package com.tarektv.pro;
public final class Channel { public final String name; public final String url; public Channel(String name,String url){this.name=name;this.url=url;} }
