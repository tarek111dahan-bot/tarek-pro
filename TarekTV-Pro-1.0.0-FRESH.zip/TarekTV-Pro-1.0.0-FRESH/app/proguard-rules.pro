# Tarek TV Pro release rules.
