# Tarek TV Pro 1.0.0 — Fresh

نسخة جديدة مستقلة. المشروع Android الحقيقي موجود في جذر المستودع، وليس داخل ZIP مطلوب فكّه أثناء البناء.

- applicationId: com.tarektv.pro
- minSdk: 23
- targetSdk: 35
- compileSdk: 36
- Java 17
- Android TV Leanback launcher + phone launcher
- M3U HTTP/HTTPS loading خارج Main Thread
- مشغل أساسي للقنوات عبر MediaPlayer

يجب أن يحتوي المستودع بعد الرفع على settings.gradle.kts و build.gradle.kts و app/ و .github/ مباشرة.
