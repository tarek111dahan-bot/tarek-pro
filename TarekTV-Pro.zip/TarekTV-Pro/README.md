# Tarek TV Pro

مشروع Android TV + Phone مستقل، مخصص لتشغيل مصادر المستخدم M3U وXtream مع مكتبة محلية ومزامنة دورية.

## المتطلبات
- Android Studio حديث
- JDK 17
- Android SDK 37
- Gradle 9.6 (يُدار في GitHub Actions)

## البناء
في GitHub Actions يتم تثبيت Gradle 9.6 ثم تنفيذ `clean assembleDebug` و`assembleRelease`.

## رفع ZIP إلى GitHub
1. أنشئ مستودعاً فارغاً جديداً على GitHub.
2. فك ضغط `TarekTV-Pro.zip` محلياً.
3. ارفع **محتويات مجلد TarekTV-Pro** إلى جذر المستودع، بحيث يكون `.github/workflows/build.yml` في جذر المستودع.
4. ادخل إلى Actions وشغّل `Build Tarek TV Pro`.
5. لا تعتبر البناء ناجحاً إلا إذا نجح Debug وRelease وظهر ملفا APK في Artifacts.

## المزامنة
- M3U: تنزيل القائمة وتحليل القنوات/VOD/Series.
- Xtream: مزامنة التصنيفات والقنوات والأفلام والمسلسلات.
- EPG: تنزيل XMLTV عند تحديد رابط EPG.
- المزامنة الدورية كل 6 ساعات عند توفر الشبكة.
- عند فشل المصدر لا يتم حذف المكتبة الحالية.
- المفضلة والسجل وموضع المشاهدة محفوظة عند تحديث العناصر.

## المصادر
التطبيق لا يضم قوائم IPTV أو محتوى طرف ثالث جاهزاً. أضف فقط المصادر التي تملك حق استخدامها.
