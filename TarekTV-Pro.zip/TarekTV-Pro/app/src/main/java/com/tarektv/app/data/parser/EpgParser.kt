package com.tarektv.app.data.parser

import com.tarektv.app.data.model.EpgProgramEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

class EpgParser{
    private val client=OkHttpClient.Builder().connectTimeout(25,TimeUnit.SECONDS).readTimeout(120,TimeUnit.SECONDS).build()
    suspend fun download(url:String)=withContext(Dispatchers.IO){val r=client.newCall(Request.Builder().url(url).header("User-Agent","TarekTV/1.0").build()).execute();r.use{if(!it.isSuccessful)error("EPG HTTP ${it.code}");it.body?.string()?:error("Empty EPG")}}
    fun parse(xml:String):List<EpgProgramEntity>{
        val p=XmlPullParserFactory.newInstance().newPullParser();p.setInput(xml.reader());val out=mutableListOf<EpgProgramEntity>();var tag="";var channel="";var title="";var desc="";var icon:String?=null;var start=0L;var end=0L;var inProgramme=false
        while(p.eventType!=XmlPullParser.END_DOCUMENT){when(p.eventType){XmlPullParser.START_TAG->{tag=p.name;if(tag=="programme"){inProgramme=true;channel=p.getAttributeValue(null,"channel").orEmpty();start=parseTime(p.getAttributeValue(null,"start"));end=parseTime(p.getAttributeValue(null,"stop"));title="";desc="";icon=null}else if(inProgramme&&tag=="icon")icon=p.getAttributeValue(null,"src")};XmlPullParser.TEXT->{if(inProgramme)when(tag){"title"->title=p.text?.trim().orEmpty();"desc"->desc=p.text?.trim().orEmpty()}};XmlPullParser.END_TAG->{if(p.name=="programme"){if(channel.isNotBlank()&&title.isNotBlank()&&end>start)out+=EpgProgramEntity(0,0,channel,title,desc.ifBlank{null},start,end,icon);inProgramme=false};tag=""}};p.next()};return out}
    private fun parseTime(raw:String?):Long{if(raw.isNullOrBlank())return 0;val clean=raw.trim();val formats=listOf("yyyyMMddHHmmss Z","yyyyMMddHHmmss") ;for(f in formats){runCatching{val sdf=SimpleDateFormat(f,Locale.US);sdf.isLenient=false;if(!clean.contains(" "))sdf.timeZone=TimeZone.getDefault();return sdf.parse(clean)?.time?:0}.getOrNull()};return 0}
}
