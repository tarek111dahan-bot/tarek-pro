package com.tarektv.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.tarektv.app.TarekTvApp
import com.tarektv.app.data.model.MediaType
import com.tarektv.app.databinding.ActivityMainBinding
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class MainActivity:AppCompatActivity(){
    private lateinit var b:ActivityMainBinding
    private val app get()=application as TarekTvApp
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);b=ActivityMainBinding.inflate(layoutInflater);setContentView(b.root);wire();observe();if(app.preferences.syncOnLaunch)lifecycleScope.launch{app.repository.syncAll()}}
    private fun wire(){
        b.cardLive.setOnClickListener{open(MediaType.LIVE)}; b.cardMovies.setOnClickListener{open(MediaType.MOVIE)}; b.cardSeries.setOnClickListener{open(MediaType.SERIES)}
        b.cardEpg.setOnClickListener{startActivity(Intent(this,EpgActivity::class.java))}; b.cardFavorites.setOnClickListener{startActivity(Intent(this,LibraryActivity::class.java).putExtra("mode","favorites"))}; b.cardSources.setOnClickListener{startActivity(Intent(this,SourcesActivity::class.java))}; b.cardSettings.setOnClickListener{startActivity(Intent(this,SettingsActivity::class.java))}
        b.btnSearch.setOnClickListener{startActivity(Intent(this,SearchActivity::class.java))}
        b.btnSync.setOnClickListener{syncNow()}
    }
    private fun observe(){ lifecycleScope.launch { app.repository.sources().collect{src-> val a=src.firstOrNull(); b.txtSource.text=a?.name ?: "أضف مصدراً"; b.txtStatus.text=if(a?.lastSync!=null)"آخر مزامنة: ${java.text.SimpleDateFormat("HH:mm",java.util.Locale.getDefault()).format(java.util.Date(a.lastSync))}" else "لم تتم المزامنة بعد"; b.btnSync.visibility=View.VISIBLE } } }
    private fun syncNow(){b.btnSync.isEnabled=false; lifecycleScope.launch{Toast.makeText(this@MainActivity,"تتم مزامنة القنوات والمكتبات…",Toast.LENGTH_SHORT).show();val errs=app.repository.syncAll();b.btnSync.isEnabled=true;if(errs.isEmpty())Toast.makeText(this@MainActivity,"تمت المزامنة بنجاح",Toast.LENGTH_SHORT).show()else Toast.makeText(this@MainActivity,errs.joinToString("\n"),Toast.LENGTH_LONG).show()}}
    private fun open(type:String){lifecycleScope.launch{val source=app.repository.sources().first().firstOrNull{it.id==app.preferences.activeSourceId} ?: app.repository.sources().first().firstOrNull();if(source==null){startActivity(Intent(this@MainActivity,AddSourceActivity::class.java));return@launch};startActivity(Intent(this@MainActivity,LibraryActivity::class.java).putExtra("type",type).putExtra("sourceId",source.id))}}
}
