package com.tarektv.app.data.repository

import android.content.Context
import androidx.room.withTransaction
import com.tarektv.app.data.db.TarekDatabase
import com.tarektv.app.data.model.*
import com.tarektv.app.data.parser.EpgParser
import com.tarektv.app.data.parser.M3uParser
import com.tarektv.app.data.remote.XtreamClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.security.MessageDigest
import kotlin.math.abs

class PlaylistRepository(private val context:Context,private val db:TarekDatabase,private val prefs:Preferences){
    private val sourceDao=db.sourceDao(); private val groupDao=db.groupDao(); private val mediaDao=db.mediaDao(); private val epgDao=db.epgDao(); private val m3u=M3uParser(); private val epg=EpgParser()
    fun sources():Flow<List<SourceEntity>>=sourceDao.observeAll()
    fun media(sourceId:Long,type:String):Flow<List<MediaEntity>>=mediaDao.observe(sourceId,type)
    fun mediaByGroup(sourceId:Long,type:String,groupId:Long):Flow<List<MediaEntity>>=mediaDao.observeByGroup(sourceId,type,groupId)
    fun episodes(sourceId:Long,seriesId:Long):Flow<List<MediaEntity>>=mediaDao.observeEpisodes(sourceId,MediaType.EPISODE,seriesId)
    suspend fun currentEpg(sourceId:Long,channelRemoteId:String,now:Long=System.currentTimeMillis())=epgDao.current(sourceId,channelRemoteId,now)
    fun groups(sourceId:Long,type:String):Flow<List<GroupEntity>>=groupDao.observe(sourceId,type)
    fun favorites():Flow<List<MediaEntity>>=mediaDao.observeFavorites()
    fun sourceHistory(sourceId:Long,type:String):Flow<List<MediaEntity>>=mediaDao.observeHistory(sourceId,type)
    suspend fun addSource(s:SourceEntity):Long=sourceDao.insert(s)
    suspend fun deleteSource(s:SourceEntity){ db.withTransaction { for(t in listOf(MediaType.LIVE,MediaType.MOVIE,MediaType.SERIES,MediaType.EPISODE)){mediaDao.deleteAll(s.id,t);if(t!=MediaType.EPISODE)groupDao.deleteAll(s.id,t)};epgDao.deleteSource(s.id);sourceDao.delete(s);if(prefs.activeSourceId==s.id)prefs.activeSourceId=-1 } }
    suspend fun setFavorite(id:Long,v:Boolean)=mediaDao.setFavorite(id,v)
    suspend fun savePosition(id:Long,p:Long,d:Long)=mediaDao.savePosition(id,p,d)
    suspend fun markWatched(id:Long,p:Long,d:Long)=mediaDao.markWatched(id,System.currentTimeMillis(),p,d)
    suspend fun search(sourceId:Long,q:String)=mediaDao.search(sourceId,q)
    suspend fun isProtected(sourceId:Long,key:String)=db.protectedDao().isProtected(sourceId,key)
    suspend fun setProtected(sourceId:Long,key:String,label:String)=db.protectedDao().upsert(ProtectedRuleEntity(sourceId=sourceId,ruleKey=key,label=label))
    suspend fun unprotect(sourceId:Long,key:String)=db.protectedDao().remove(sourceId,key)

    suspend fun syncAll():List<String> = withContext(Dispatchers.IO){
        sourceDao.getEnabled().mapNotNull { src ->
            try {
                sync(src)
                null
            } catch (error: Throwable) {
                val message = error.message ?: "Sync failed"
                sourceDao.markError(src.id, message.take(500))
                "${src.name}: $message"
            }
        }
    }

    suspend fun sync(source:SourceEntity)=withContext(Dispatchers.IO){
        when(source.type){SourceType.M3U->syncM3u(source);SourceType.XTREAM->syncXtream(source);else->error("Unsupported source type: ${source.type}")}
        source.epgUrl?.takeIf{it.isNotBlank()}?.let{runCatching{syncEpg(source,it)}}
    }

    private suspend fun syncM3u(source:SourceEntity){
        val items=m3u.parse(source.url); if(items.isEmpty())error("Playlist is empty")
        val groups=mutableListOf<GroupEntity>()
        items.groupBy{it.type to (it.group?.trim().orEmpty())}.filterKeys{it.second.isNotBlank()}.forEach{(key,list)->
            val (type,name)=key; groups += GroupEntity(stable(source.id,type,"GROUP:$name"),source.id,type,name,name,list.size)
        }
        val incoming=items.map{it->
            val type=it.type; val remote=it.tvgId?.ifBlank{null} ?: it.url; val g=it.group?.trim().orEmpty().takeIf{it.isNotBlank()}; val gid=g?.let{name->stable(source.id,type,"GROUP:$name")}
            MediaEntity(id=stable(source.id,type,remote),sourceId=source.id,type=type,remoteId=remote,groupId=gid,name=it.name,url=it.url,logo=it.logo,adult=it.adult)
        }
        storeSynced(source,incoming,groups)
        incoming.filter{it.adult}.forEach{setProtected(source.id,"MEDIA:${it.type}:${it.id}",it.name)}
        groups.filter{it.name.lowercase().let{n->listOf("adult","xxx","18+","بالغ","إباح").any(n::contains)}}.forEach{setProtected(source.id,"GROUP:${it.type}:${it.id}",it.name)}
    }

    private suspend fun syncXtream(source:SourceEntity){
        val u=source.username?.trim().orEmpty(); val p=source.password?.trim().orEmpty(); require(u.isNotBlank()&&p.isNotBlank()){ "Xtream credentials are required" }
        val client=XtreamClient(source.url); val auth=client.api.auth(u,p); require(auth.user_info?.auth==1 || auth.user_info?.status?.equals("Active",true)==true){ "Xtream authentication failed" }
        val lg=client.api.liveCategories(u,p); val lc=client.api.liveStreams(u,p); val vg=client.api.vodCategories(u,p); val vm=client.api.vodStreams(u,p); val sg=client.api.seriesCategories(u,p); val ss=client.api.series(u,p)
        val groups=buildList{lg.forEach{g->g.category_id?.let{id->add(GroupEntity(stable(source.id,MediaType.LIVE,"GROUP:$id"),source.id,MediaType.LIVE,id,g.category_name?:id))}};vg.forEach{g->g.category_id?.let{id->add(GroupEntity(stable(source.id,MediaType.MOVIE,"GROUP:$id"),source.id,MediaType.MOVIE,id,g.category_name?:id))}};sg.forEach{g->g.category_id?.let{id->add(GroupEntity(stable(source.id,MediaType.SERIES,"GROUP:$id"),source.id,MediaType.SERIES,id,g.category_name?:id))}}}
        val live=lc.mapNotNull{v->v.stream_id?.toString()?.let{id->val gid=v.category_id?.let{c->stable(source.id,MediaType.LIVE,"GROUP:$c")};MediaEntity(stable(source.id,MediaType.LIVE,id),source.id,MediaType.LIVE,id,gid,v.name?:id,client.url(MediaType.LIVE,id,u,p,"ts"),v.stream_icon,adult=isAdult(v.name.orEmpty()))}}
        val movies=vm.mapNotNull{v->v.stream_id?.toString()?.let{id->val gid=v.category_id?.let{c->stable(source.id,MediaType.MOVIE,"GROUP:$c")};MediaEntity(stable(source.id,MediaType.MOVIE,id),source.id,MediaType.MOVIE,id,gid,v.name?:id,client.url(MediaType.MOVIE,id,u,p,v.container_extension?:"mp4"),v.stream_icon,v.plot,v.releasedate?.take(4)?.toIntOrNull(),adult=isAdult(v.name.orEmpty()))}}
        val series=ss.mapNotNull{v->v.series_id?.toString()?.let{id->val gid=v.category_id?.let{c->stable(source.id,MediaType.SERIES,"GROUP:$c")};MediaEntity(stable(source.id,MediaType.SERIES,id),source.id,MediaType.SERIES,id,gid,v.name?:id,client.url(MediaType.SERIES,id,u,p,"mp4"),v.cover,v.plot,v.releaseDate?.take(4)?.toIntOrNull(),adult=isAdult(v.name.orEmpty()))}}
        storeSynced(source,live+movies+series,groups)
        // Mark detected adult entries as protected by default; no external content is bundled by the app.
        (live+movies+series).filter{it.adult}.forEach{setProtected(source.id,"MEDIA:${it.type}:${it.id}",it.name)}
        groups.filter{it.name.lowercase().let{n->listOf("adult","xxx","18+","بالغ","إباح").any(n::contains)}}.forEach{setProtected(source.id,"GROUP:${it.type}:${it.id}",it.name)}
    }

    private suspend fun storeSynced(source:SourceEntity,incoming:List<MediaEntity>,groups:List<GroupEntity>){
        if(incoming.isEmpty())error("Source returned no playable items")
        db.withTransaction{
            val byType=listOf(MediaType.LIVE,MediaType.MOVIE,MediaType.SERIES,MediaType.EPISODE).associateWith{type->mediaDao.getAll(source.id,type).associateBy{it.remoteId}}
            listOf(MediaType.LIVE,MediaType.MOVIE,MediaType.SERIES).forEach{type->
                val list=incoming.filter{it.type==type}.map{new->byType[type]?.get(new.remoteId)?.let{old->new.copy(isFavorite=old.isFavorite,lastWatched=old.lastWatched,watchCount=old.watchCount,lastPositionMs=old.lastPositionMs,durationMs=old.durationMs)}?:new}
                if(list.isNotEmpty()){mediaDao.deleteAll(source.id,type);mediaDao.upsertAll(list)}
                else mediaDao.deleteAll(source.id,type)
            }
            listOf(MediaType.LIVE,MediaType.MOVIE,MediaType.SERIES).forEach{type->groupDao.deleteAll(source.id,type)};groupDao.upsertAll(groups);mediaDao.deleteOrphanEpisodes(source.id)
            sourceDao.markSuccess(source.id,System.currentTimeMillis(),incoming.count{it.type==MediaType.LIVE},incoming.count{it.type==MediaType.MOVIE},incoming.count{it.type==MediaType.SERIES})
        }
    }

    private suspend fun syncEpg(source:SourceEntity,url:String){val text=epg.download(url);val programs=epg.parse(text).map{it.copy(sourceId=source.id,id=stable(source.id,"EPG","${it.channelRemoteId}|${it.startMs}|${it.title}"))};if(programs.isEmpty())return;db.withTransaction{epgDao.deleteSource(source.id);epgDao.upsertAll(programs)}}
    suspend fun loadSeriesEpisodes(sourceId:Long,seriesId:Long){
        val source=sourceDao.get(sourceId) ?: return
        if(source.type!=SourceType.XTREAM) return
        val s=mediaDao.getAll(sourceId,MediaType.SERIES).firstOrNull{it.id==seriesId} ?: return
        val user=source.username.orEmpty(); val pass=source.password.orEmpty(); val client=XtreamClient(source.url);
        val info=client.api.seriesInfo(user,pass,s.remoteId)
        val incoming=info.episodes.orEmpty().flatMap{(_,eps)->eps.mapNotNull{e->
            val id=(e["id"]?.toString() ?: e["episode_num"]?.toString())?.takeIf{it.isNotBlank()} ?: return@mapNotNull null
            val season=(e["season"]?.toString()?.toDoubleOrNull()?.toInt()) ?: 0; val number=(e["episode_num"]?.toString()?.toDoubleOrNull()?.toInt()) ?: 0
            val title=e["title"]?.toString().orEmpty().ifBlank{"الحلقة $number"}; val ext=e["container_extension"]?.toString().orEmpty().ifBlank{"mp4"}; val stream=client.url("SERIES",id,user,pass,ext)
            MediaEntity(stable(sourceId,MediaType.EPISODE,"${s.remoteId}:$id"),sourceId,MediaType.EPISODE,id,s.id,title,stream,e["movie_image"]?.toString() ?: s.logo,null,null,season,number,s.adult)
        }}
        if(incoming.isNotEmpty()){mediaDao.deleteGroup(sourceId,MediaType.EPISODE,s.id);mediaDao.upsertAll(incoming)}
    }
    fun adultKey(type:String,id:Long)="MEDIA:$type:$id"
    private fun isAdult(s:String)=listOf("xxx","adult","18+","porn","sex","إباح","بالغ").any{s.lowercase().contains(it)}
    private fun stable(source:Long,type:String,key:String):Long{val h=MessageDigest.getInstance("SHA-256").digest("$source|$type|$key".toByteArray());var v=0L;for(i in 0 until 8)v=(v shl 8) or (h[i].toLong() and 255);return abs(if(v==Long.MIN_VALUE)Long.MAX_VALUE else v).coerceAtLeast(1)}
}
