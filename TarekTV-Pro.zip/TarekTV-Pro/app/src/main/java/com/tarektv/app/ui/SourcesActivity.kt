package com.tarektv.app.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.tarektv.app.TarekTvApp
import com.tarektv.app.data.model.SourceEntity
import com.tarektv.app.databinding.ActivitySourcesBinding
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class SourcesActivity:AppCompatActivity(){
    private lateinit var b:ActivitySourcesBinding;private val app get()=application as TarekTvApp;private val list=mutableListOf<SourceEntity>()
    override fun onCreate(s:Bundle?){super.onCreate(s);b=ActivitySourcesBinding.inflate(layoutInflater);setContentView(b.root);b.rv.layoutManager=LinearLayoutManager(this);b.add.setOnClickListener{startActivity(Intent(this,AddSourceActivity::class.java))};b.back.setOnClickListener{finish()};lifecycleScope.launch{app.repository.sources().collectLatest{list.clear();list.addAll(it);b.empty.text=if(it.isEmpty())"لا توجد مصادر. أضف M3U أو Xtream." else it.joinToString("\n\n"){x->"${x.name} — ${x.type}\n${x.url}\nLive ${x.liveCount} · VOD ${x.movieCount} · Series ${x.seriesCount}"}}}}
}
