package com.tarektv.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.tarektv.app.data.model.*

@Database(entities=[SourceEntity::class,GroupEntity::class,MediaEntity::class,EpgProgramEntity::class,ProtectedRuleEntity::class],version=1,exportSchema=false)
abstract class TarekDatabase:RoomDatabase(){
    abstract fun sourceDao():SourceDao
    abstract fun groupDao():GroupDao
    abstract fun mediaDao():MediaDao
    abstract fun epgDao():EpgDao
    abstract fun protectedDao():ProtectedDao
    companion object{
        @Volatile private var INSTANCE:TarekDatabase?=null
        fun getInstance(context:Context):TarekDatabase=INSTANCE?: synchronized(this){
            INSTANCE?:Room.databaseBuilder(context.applicationContext,TarekDatabase::class.java,"tarek_tv_pro.db").build().also{INSTANCE=it}
        }
    }
}
