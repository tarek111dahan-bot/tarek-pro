package com.tarektv.app.player

import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.LoadControl
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory

@UnstableApi
object PlayerEngine {
    fun create(context:Context):ExoPlayer{
        val http=DefaultHttpDataSource.Factory().setConnectTimeoutMs(30_000).setReadTimeoutMs(90_000).setAllowCrossProtocolRedirects(true).setUserAgent("TarekTV/1.0")
        val load:LoadControl=DefaultLoadControl.Builder().setBufferDurationsMs(20_000,60_000,1_500,3_000).build()
        return ExoPlayer.Builder(context).setLoadControl(load).setMediaSourceFactory(DefaultMediaSourceFactory(http)).build()
    }
    fun item(url:String,title:String,mime:String?=null):MediaItem=MediaItem.Builder().setUri(url).setMediaMetadata(androidx.media3.common.MediaMetadata.Builder().setTitle(title).build()).apply{if(!mime.isNullOrBlank())setMimeType(mime)}.build()
    fun guessMime(url:String):String?=when{url.contains(".m3u8",true)->MimeTypes.APPLICATION_M3U8; url.endsWith(".mpd",true)->MimeTypes.APPLICATION_MPD; url.contains(".ts",true)->MimeTypes.VIDEO_MP2T; url.endsWith(".mp4",true)->MimeTypes.VIDEO_MP4; else->null}
}
