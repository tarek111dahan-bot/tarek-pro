package com.tarektv.app.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.tarektv.app.TarekTvApp
import com.tarektv.app.data.model.MediaEntity
import com.tarektv.app.data.model.MediaType
import com.tarektv.app.databinding.ActivityLibraryBinding
import com.tarektv.app.player.PinManager
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class LibraryActivity:AppCompatActivity(){
    private lateinit var b:ActivityLibraryBinding;private val app get()=application as TarekTvApp;private var sourceId=-1L;private var type=MediaType.LIVE;private lateinit var adapter:MediaAdapter
    override fun onCreate(s:Bundle?){super.onCreate(s);b=ActivityLibraryBinding.inflate(layoutInflater);setContentView(b.root);sourceId=intent.getLongExtra("sourceId",app.preferences.activeSourceId);type=intent.getStringExtra("type")?:MediaType.LIVE;if(intent.getStringExtra("mode")=="favorites")sourceId=-1;setup();observe()}
    private fun setup(){b.empty.text=when(type){MediaType.LIVE->"القنوات";MediaType.MOVIE->"الأفلام";MediaType.SERIES->"المسلسلات";else->"المكتبة"};b.rv.layoutManager=GridLayoutManager(this,5);adapter=MediaAdapter({item->play(item)}){item,v->lifecycleScope.launch{app.repository.setFavorite(item.id,v)}};b.rv.adapter=adapter;b.btnBack.setOnClickListener{finish()}}
    private fun observe(){lifecycleScope.launch{if(sourceId==-1L)app.repository.favorites().collectLatest{adapter.submit(it)}else app.repository.media(sourceId,type).collectLatest{adapter.submit(it)}}}
    private fun play(item:MediaEntity){PinManager.runProtected(this,item.sourceId,app.repository.adultKey(item.type,item.id),item.name){val target=if(item.type==MediaType.SERIES)SeriesDetailActivity::class.java else PlayerActivity::class.java;startActivity(Intent(this,target).putExtra("mediaId",item.id).putExtra("sourceId",item.sourceId).putExtra("url",item.url).putExtra("title",item.name))}}
}
