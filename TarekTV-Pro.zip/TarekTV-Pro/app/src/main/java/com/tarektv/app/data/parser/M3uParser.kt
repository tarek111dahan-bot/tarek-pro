package com.tarektv.app.data.parser

import com.tarektv.app.data.model.MediaType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.BufferedReader
import java.io.StringReader
import java.util.concurrent.TimeUnit

private val attrRegex = Regex("([\\w-]+)=\"([^\"]*)\"")

data class ParsedM3uItem(
    val name:String,
    val url:String,
    val logo:String?,
    val group:String?,
    val tvgId:String?,
    val type:String,
    val adult:Boolean
)

class M3uParser {
    private val client = OkHttpClient.Builder().connectTimeout(25,TimeUnit.SECONDS).readTimeout(90,TimeUnit.SECONDS).build()

    suspend fun parse(url:String):List<ParsedM3uItem> = withContext(Dispatchers.IO) {
        val response = client.newCall(Request.Builder().url(url).header("User-Agent","TarekTV/1.0").build()).execute()
        response.use {
            if(!it.isSuccessful) error("HTTP ${it.code}")
            val body=it.body?.string() ?: error("Empty playlist")
            parseText(body)
        }
    }

    fun parseText(text:String):List<ParsedM3uItem>{
        val reader=BufferedReader(StringReader(text)); val out=mutableListOf<ParsedM3uItem>(); var ext:String?=null; var attrs=emptyMap<String,String>()
        while(true){
            val raw=reader.readLine()?:break; val line=raw.trim(); if(line.isEmpty() || line.startsWith("#EXTM3U")) continue
            if(line.startsWith("#EXTINF",ignoreCase=true)){
                ext=line.substringAfter(":"); attrs=attrRegex.findAll(ext).associate{it.groupValues[1].lowercase() to it.groupValues[2]}; continue
            }
            if(!line.startsWith("#") && ext!=null){
                val name=ext.substringAfterLast(",").trim().ifBlank{"Unnamed"}; val group=attrs["group-title"]
                val type=classify(name,group,line); val adult=isAdult("$name ${group.orEmpty()}")
                out += ParsedM3uItem(name,line,attrs["tvg-logo"]?.ifBlank{null},group,attrs["tvg-id"],type,adult); ext=null; attrs=emptyMap()
            }
        }
        return out
    }

    private fun classify(name:String,group:String?,url:String):String{
        val s="$name ${group.orEmpty()} $url".lowercase()
        return when {
            listOf("series","مسلسل","season","episode").any{s.contains(it)} -> MediaType.SERIES
            listOf("movie","film","فيلم","vod").any{s.contains(it)} -> MediaType.MOVIE
            else -> MediaType.LIVE
        }
    }
    private fun isAdult(s:String):Boolean = listOf("xxx","adult","18+","porn","sex","إباح","بالغ").any{s.lowercase().contains(it)}
}
