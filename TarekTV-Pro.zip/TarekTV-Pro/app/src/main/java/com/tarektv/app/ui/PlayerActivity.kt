package com.tarektv.app.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import com.google.android.gms.cast.MediaInfo
import com.google.android.gms.cast.MediaLoadRequestData
import com.google.android.gms.cast.MediaMetadata
import com.google.android.gms.cast.framework.CastButtonFactory
import com.google.android.gms.cast.framework.CastSession
import com.google.android.gms.cast.framework.SessionManagerListener
import com.tarektv.app.TarekTvApp
import com.tarektv.app.databinding.ActivityPlayerBinding
import com.tarektv.app.player.PlayerEngine
import kotlinx.coroutines.launch

class PlayerActivity : AppCompatActivity() {
    private lateinit var b: ActivityPlayerBinding
    private val app get() = application as TarekTvApp
    private var player: androidx.media3.exoplayer.ExoPlayer? = null
    private var mediaId = -1L
    private var castStarted = false

    private val castListener = object : SessionManagerListener<CastSession> {
        override fun onSessionStarted(session: CastSession, sessionId: String) { loadToCast(session) }
        override fun onSessionResumed(session: CastSession, wasSuspended: Boolean) { if (!castStarted) loadToCast(session) }
        override fun onSessionEnded(session: CastSession, error: Int) { castStarted = false; player?.play() }
        override fun onSessionStartFailed(session: CastSession, error: Int) { castStarted = false; Toast.makeText(this@PlayerActivity, "تعذر بدء Chromecast", Toast.LENGTH_SHORT).show() }
        override fun onSessionStarting(session: CastSession) = Unit
        override fun onSessionEnding(session: CastSession) = Unit
        override fun onSessionResuming(session: CastSession, sessionId: String) = Unit
        override fun onSessionSuspended(session: CastSession, reason: Int) = Unit
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        b = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(b.root)
        mediaId = intent.getLongExtra("mediaId", -1L)
        b.title.text = intent.getStringExtra("title").orEmpty()
        CastButtonFactory.setUpMediaRouteButton(applicationContext, b.cast)
        appCastManager()?.addSessionManagerListener(castListener, CastSession::class.java)

        val external = app.preferences.externalPlayerPackage
        val url = intent.getStringExtra("url")
        if (!url.isNullOrBlank() && !external.isNullOrBlank()) {
            runCatching {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    setPackage(external)
                    setDataAndType(Uri.parse(url), "video/*")
                })
                finish()
            }.onFailure { startInternal() }
        } else startInternal()
    }

    private fun appCastManager() = runCatching { com.google.android.gms.cast.framework.CastContext.getSharedInstance(this).sessionManager }.getOrNull()

    private fun startInternal() {
        val url = intent.getStringExtra("url") ?: return
        player = PlayerEngine.create(this).also { p ->
            b.player.player = p
            val builder = MediaItem.Builder().setUri(url).setMediaMetadata(
                androidx.media3.common.MediaMetadata.Builder().setTitle(b.title.text.toString()).build()
            )
            PlayerEngine.guessMime(url)?.let { builder.setMimeType(it) }
            intent.getStringExtra("subtitle_url")?.takeIf { it.isNotBlank() }?.let { u ->
                builder.setSubtitleConfigurations(listOf(MediaItem.SubtitleConfiguration.Builder(Uri.parse(u))
                    .setMimeType(MimeTypes.APPLICATION_SUBRIP).setLanguage("ar").setLabel("العربية").build()))
            }
            p.setMediaItem(builder.build())
            p.prepare()
            p.seekTo(intent.getLongExtra("position", 0L).coerceAtLeast(0L))
            p.play()
            p.addListener(object : Player.Listener {
                override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                    Toast.makeText(this@PlayerActivity, "تعذر تشغيل المصدر: ${error.errorCodeName}", Toast.LENGTH_LONG).show()
                }
            })
        }
    }

    private fun loadToCast(session: CastSession) {
        val url = intent.getStringExtra("url") ?: return
        val type = when {
            url.contains(".m3u8", true) -> "application/x-mpegURL"
            url.contains(".mpd", true) -> "application/dash+xml"
            url.contains(".ts", true) -> "video/mp2t"
            else -> "video/mp4"
        }
        val metadata = MediaMetadata(MediaMetadata.MEDIA_TYPE_MOVIE).apply {
            putString(MediaMetadata.KEY_TITLE, b.title.text.toString())
        }
        val info = MediaInfo.Builder(url).setContentType(type).setStreamType(MediaInfo.STREAM_TYPE_BUFFERED).setMetadata(metadata).build()
        session.remoteMediaClient?.load(MediaLoadRequestData.Builder().setMediaInfo(info).build())
        castStarted = true
        player?.pause()
    }

    override fun onPause() {
        super.onPause()
        player?.let { p ->
            if (mediaId != -1L) lifecycleScope.launch {
                app.repository.savePosition(mediaId, p.currentPosition, p.duration.coerceAtLeast(0L))
                if (p.currentPosition > 30_000) app.repository.markWatched(mediaId, p.currentPosition, p.duration.coerceAtLeast(0L))
            }
        }
    }

    override fun onDestroy() {
        appCastManager()?.removeSessionManagerListener(castListener, CastSession::class.java)
        b.player.player = null
        player?.release()
        super.onDestroy()
    }
}
