# Tarek TV Pro 1.0.0

مشروع Android TV/Phone مستقل لتشغيل مصادر M3U وإدارة القنوات والمفضلة والمزامنة المحلية.

## البناء

- Android Gradle Plugin: 9.4.0
- Gradle: 9.6.0
- JDK: 17
- compileSdk: 36
- targetSdk: 36
- minSdk: 23
- Media3: 1.11.1
- WorkManager: 2.11.2

## GitHub

المشروع مصمم ليكون في جذر المستودع بعد فك الضغط. ملف workflow الموجود في `.github/workflows/build.yml` يقوم بتثبيت Gradle 9.6، ويولد Wrapper الرسمي عند غيابه، ثم يبني Debug وRelease ويرفعهما كـArtifacts.
