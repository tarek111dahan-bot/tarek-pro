#!/usr/bin/env bash
set -euo pipefail
required=(
  settings.gradle.kts
  build.gradle.kts
  gradle.properties
  gradle/wrapper/gradle-wrapper.properties
  gradlew
  gradlew.bat
  app/build.gradle.kts
  app/src/main/AndroidManifest.xml
  app/src/main/java/com/tarektv/MainActivity.java
  app/src/main/java/com/tarektv/LibraryActivity.java
  app/src/main/java/com/tarektv/PlayerActivity.java
  app/src/main/java/com/tarektv/M3uParser.java
  app/src/main/java/com/tarektv/PlaylistRepository.java
  app/src/main/java/com/tarektv/SyncWorker.java
  app/src/main/java/com/tarektv/SyncManager.java
)
for f in "${required[@]}"; do test -f "$f" || { echo "MISSING: $f"; exit 1; }; done
grep -q 'com.android.application.*9.4.0' build.gradle.kts
grep -q 'distributionUrl=.*gradle-9.6-bin.zip' gradle/wrapper/gradle-wrapper.properties
grep -q 'minSdk = 23' app/build.gradle.kts
grep -q 'compileSdk = 36' app/build.gradle.kts
grep -q 'targetSdk = 36' app/build.gradle.kts
grep -q 'media3-exoplayer:1.11.1' app/build.gradle.kts
grep -q 'work-runtime:2.11.2' app/build.gradle.kts
echo 'Tarek TV Pro project structural validation: OK'
