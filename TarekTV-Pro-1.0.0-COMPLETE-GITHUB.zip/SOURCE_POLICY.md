# Source policy

Tarek TV Pro does not bundle third-party channel URLs. Users add lawful M3U sources they are authorized to use.
The application only parses and plays source URLs supplied by the user.
