@ECHO OFF
SETLOCAL
SET APP_HOME=%~dp0
SET WRAPPER_JAR=%APP_HOME%gradle\wrapper\gradle-wrapper.jar
IF NOT EXIST "%WRAPPER_JAR%" (
  ECHO ERROR: gradle\wrapper\gradle-wrapper.jar is missing.
  ECHO Use the supplied GitHub Actions workflow or generate the official wrapper with:
  ECHO   gradle wrapper --gradle-version 9.6
  EXIT /B 1
)
IF NOT DEFINED JAVA_HOME (
  SET JAVACMD=java.exe
) ELSE (
  SET JAVACMD=%JAVA_HOME%\bin\java.exe
)
"%JAVACMD%" -classpath "%WRAPPER_JAR%" org.gradle.wrapper.GradleWrapperMain %*
ENDLOCAL
