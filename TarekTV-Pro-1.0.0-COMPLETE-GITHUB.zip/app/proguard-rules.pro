# Tarek TV Pro 1.0.0
# Keep application model classes used by JSON / reflection if future integrations need them.
-keep class com.tarektv.** { *; }
