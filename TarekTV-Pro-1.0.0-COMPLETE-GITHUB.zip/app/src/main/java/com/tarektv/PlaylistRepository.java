package com.tarektv;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class PlaylistRepository {
    private static final String PREFS = "tarek_tv_store";
    private static final String SOURCES = "sources";
    private static final String CHANNELS = "channels";
    private static final String FAVORITES = "favorites";
    private final SharedPreferences prefs;

    public PlaylistRepository(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public synchronized List<Source> getSources() {
        List<Source> result = new ArrayList<>();
        JSONArray a = readArray(SOURCES);
        for (int i = 0; i < a.length(); i++) {
            result.add(Source.fromJson(a.optJSONObject(i)));
        }
        return result;
    }

    public synchronized void addSource(Source source) {
        List<Source> sources = getSources();
        sources.removeIf(s -> s.id.equals(source.id));
        sources.add(source);
        JSONArray a = new JSONArray();
        for (Source s : sources) a.put(s.toJson());
        prefs.edit().putString(SOURCES, a.toString()).apply();
    }

    public synchronized void removeSource(String id) {
        List<Source> sources = getSources();
        sources.removeIf(s -> s.id.equals(id));
        JSONArray a = new JSONArray();
        for (Source s : sources) a.put(s.toJson());
        prefs.edit().putString(SOURCES, a.toString()).apply();
    }

    public synchronized List<Channel> getChannels() {
        List<Channel> result = new ArrayList<>();
        JSONArray a = readArray(CHANNELS);
        for (int i = 0; i < a.length(); i++) result.add(Channel.fromJson(a.optJSONObject(i)));
        return result;
    }

    public synchronized void replaceChannels(List<Channel> channels) {
        JSONArray a = new JSONArray();
        for (Channel c : channels) {
            try { a.put(c.toJson()); } catch (Exception ignored) {}
        }
        prefs.edit().putString(CHANNELS, a.toString()).apply();
    }

    public synchronized void mergeChannels(List<Channel> incoming) {
        List<Channel> all = getChannels();
        java.util.LinkedHashMap<String, Channel> map = new java.util.LinkedHashMap<>();
        for (Channel c : all) map.put(c.id, c);
        for (Channel c : incoming) map.put(c.id, c);
        replaceChannels(new ArrayList<>(map.values()));
    }

    public synchronized boolean isFavorite(String channelId) {
        return readArray(FAVORITES).toString().contains("\"" + channelId.replace("\"", "\\\"") + "\"");
    }

    public synchronized void toggleFavorite(String channelId) {
        JSONArray a = readArray(FAVORITES);
        JSONArray out = new JSONArray();
        boolean removed = false;
        for (int i = 0; i < a.length(); i++) {
            String id = a.optString(i);
            if (id.equals(channelId)) { removed = true; continue; }
            out.put(id);
        }
        if (!removed) out.put(channelId);
        prefs.edit().putString(FAVORITES, out.toString()).apply();
    }

    public synchronized List<Channel> getFavorites() {
        List<String> ids = new ArrayList<>();
        JSONArray a = readArray(FAVORITES);
        for (int i = 0; i < a.length(); i++) ids.add(a.optString(i));
        List<Channel> result = new ArrayList<>();
        for (Channel c : getChannels()) if (ids.contains(c.id)) result.add(c);
        return result;
    }

    public synchronized void clearAll() {
        prefs.edit().clear().apply();
    }

    public boolean getAutoSync() {
        return prefs.getBoolean("auto_sync", true);
    }

    public void setAutoSync(boolean enabled) {
        prefs.edit().putBoolean("auto_sync", enabled).apply();
    }

    private JSONArray readArray(String key) {
        try { return new JSONArray(prefs.getString(key, "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }
}
