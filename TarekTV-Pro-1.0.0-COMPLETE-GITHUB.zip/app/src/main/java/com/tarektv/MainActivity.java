package com.tarektv;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public final class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = Ui.column(this);
        root.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = Ui.title(this, getString(R.string.home_title));
        root.addView(title, new LinearLayout.LayoutParams(-1, Ui.dp(this, 72)));
        root.addView(Ui.body(this, getString(R.string.home_subtitle)), new LinearLayout.LayoutParams(-1, -2));

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        row.setOrientation(LinearLayout.HORIZONTAL);
        String[] labels = {getString(R.string.channels), getString(R.string.movies), getString(R.string.series)};
        String[] groups = {"القنوات", "الأفلام", "المسلسلات"};
        for (int i = 0; i < labels.length; i++) {
            Button b = Ui.cardButton(this, labels[i]);
            final String g = groups[i];
            b.setOnClickListener(v -> openLibrary(g));
            row.addView(b, new LinearLayout.LayoutParams(0, Ui.dp(this, 120), 1));
        }
        root.addView(row, new LinearLayout.LayoutParams(-1, Ui.dp(this, 140)));

        LinearLayout row2 = new LinearLayout(this);
        row2.setGravity(Gravity.CENTER);
        Button fav = Ui.cardButton(this, getString(R.string.favorites));
        fav.setOnClickListener(v -> openLibrary("__favorites__"));
        Button sources = Ui.cardButton(this, getString(R.string.sources));
        sources.setOnClickListener(v -> startActivity(new Intent(this, SourcesActivity.class)));
        Button settings = Ui.cardButton(this, getString(R.string.settings));
        settings.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        row2.addView(fav, new LinearLayout.LayoutParams(0, Ui.dp(this, 110), 1));
        row2.addView(sources, new LinearLayout.LayoutParams(0, Ui.dp(this, 110), 1));
        row2.addView(settings, new LinearLayout.LayoutParams(0, Ui.dp(this, 110), 1));
        root.addView(row2, new LinearLayout.LayoutParams(-1, Ui.dp(this, 130)));

        Button search = Ui.cardButton(this, getString(R.string.search));
        search.setOnClickListener(v -> startActivity(new Intent(this, SearchActivity.class)));
        root.addView(search, new LinearLayout.LayoutParams(Ui.dp(this, 320), Ui.dp(this, 80)));

        setContentView(root);
    }

    private void openLibrary(String group) {
        Intent i = new Intent(this, LibraryActivity.class);
        i.putExtra("group", group);
        startActivity(i);
    }
}
