package com.tarektv;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public final class SettingsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        PlaylistRepository repo = new PlaylistRepository(this);
        LinearLayout root = Ui.column(this);
        root.addView(Ui.title(this, getString(R.string.settings)));

        CheckBox auto = new CheckBox(this);
        auto.setText(getString(R.string.auto_sync));
        auto.setTextColor(android.graphics.Color.WHITE);
        auto.setChecked(repo.getAutoSync());
        root.addView(auto, new LinearLayout.LayoutParams(-1, Ui.dp(this, 70)));

        Button interval = Ui.cardButton(this, getString(R.string.sync_interval));
        interval.setOnClickListener(v -> Toast.makeText(this, "تعمل المزامنة التلقائية كل 12 ساعة عند توفر الشبكة", Toast.LENGTH_LONG).show());
        root.addView(interval, new LinearLayout.LayoutParams(-1, Ui.dp(this, 74)));

        Button sync = Ui.cardButton(this, getString(R.string.sync_now));
        sync.setOnClickListener(v -> {
            SyncManager.schedule(this);
            Toast.makeText(this, "تم جدولة المزامنة", Toast.LENGTH_SHORT).show();
        });
        root.addView(sync, new LinearLayout.LayoutParams(-1, Ui.dp(this, 74)));

        Button clear = Ui.cardButton(this, getString(R.string.clear_data));
        clear.setOnClickListener(v -> {
            repo.clearAll();
            SyncManager.schedule(this);
            Toast.makeText(this, "تم مسح البيانات المحلية", Toast.LENGTH_SHORT).show();
        });
        root.addView(clear, new LinearLayout.LayoutParams(-1, Ui.dp(this, 74)));

        auto.setOnCheckedChangeListener((buttonView, isChecked) -> { repo.setAutoSync(isChecked); SyncManager.schedule(this); });
        setContentView(root);
    }
}
