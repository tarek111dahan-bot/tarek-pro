package com.tarektv;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

public final class AddSourceActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = Ui.column(this);
        root.addView(Ui.title(this, getString(R.string.add_source)));

        EditText name = new EditText(this);
        name.setHint(getString(R.string.source_name));
        name.setTextColor(android.graphics.Color.WHITE);
        name.setHintTextColor(android.graphics.Color.GRAY);
        root.addView(name, new LinearLayout.LayoutParams(-1, Ui.dp(this, 70)));

        EditText url = new EditText(this);
        url.setHint(getString(R.string.source_url));
        url.setTextColor(android.graphics.Color.WHITE);
        url.setHintTextColor(android.graphics.Color.GRAY);
        url.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        root.addView(url, new LinearLayout.LayoutParams(-1, Ui.dp(this, 70)));

        Button save = Ui.cardButton(this, getString(R.string.save));
        save.setOnClickListener(v -> {
            String n = name.getText().toString().trim();
            String u = url.getText().toString().trim();
            if (n.isEmpty() || u.isEmpty()) {
                Toast.makeText(this, "أدخل اسم المصدر والرابط", Toast.LENGTH_SHORT).show();
                return;
            }
            Source s = new Source(UUID.nameUUIDFromBytes(u.getBytes(StandardCharsets.UTF_8)).toString(), n, u, System.currentTimeMillis());
            PlaylistRepository repo = new PlaylistRepository(this);
            repo.addSource(s);
            SyncManager.schedule(this);
            Toast.makeText(this, "تم حفظ المصدر", Toast.LENGTH_SHORT).show();
            finish();
        });
        root.addView(save, new LinearLayout.LayoutParams(-1, Ui.dp(this, 74)));

        Button cancel = Ui.cardButton(this, getString(R.string.cancel));
        cancel.setOnClickListener(v -> finish());
        root.addView(cancel, new LinearLayout.LayoutParams(-1, Ui.dp(this, 74)));
        setContentView(root);
    }
}
