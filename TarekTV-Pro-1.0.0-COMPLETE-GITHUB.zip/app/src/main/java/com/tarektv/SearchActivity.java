package com.tarektv;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public final class SearchActivity extends AppCompatActivity {
    private PlaylistRepository repo;
    private LinearLayout list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        repo = new PlaylistRepository(this);
        LinearLayout root = Ui.column(this);
        root.addView(Ui.title(this, getString(R.string.search)));
        EditText q = new EditText(this);
        q.setTextColor(android.graphics.Color.WHITE);
        q.setHintTextColor(android.graphics.Color.GRAY);
        q.setHint("اكتب اسم القناة أو المجموعة");
        root.addView(q, new LinearLayout.LayoutParams(-1, Ui.dp(this, 68)));
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        q.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a) {}
            public void onTextChanged(CharSequence s,int st,int b,int c) { render(s.toString()); }
            public void afterTextChanged(android.text.Editable e) {}
        });
    }
    private void render(String text) {
        list.removeAllViews();
        String q = text.trim().toLowerCase(java.util.Locale.ROOT);
        for (Channel c : repo.getChannels()) {
            if (!q.isEmpty() && !(c.name.toLowerCase(java.util.Locale.ROOT).contains(q) || c.group.toLowerCase(java.util.Locale.ROOT).contains(q))) continue;
            Button b = Ui.cardButton(this, c.name + "\n" + c.group);
            b.setOnClickListener(v -> {
                Intent i = new Intent(this, PlayerActivity.class);
                i.putExtra("channel_id", c.id); i.putExtra("channel_name", c.name); i.putExtra("channel_url", c.url);
                startActivity(i);
            });
            list.addView(b, new LinearLayout.LayoutParams(-1, Ui.dp(this, 82)));
        }
    }
}
