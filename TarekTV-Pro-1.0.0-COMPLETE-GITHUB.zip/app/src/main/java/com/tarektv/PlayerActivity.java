package com.tarektv;

import android.os.Bundle;
import android.view.KeyEvent;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

import java.util.List;

public final class PlayerActivity extends AppCompatActivity {
    private ExoPlayer player;
    private List<Channel> channels;
    private int index = -1;
    private PlaylistRepository repo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        repo = new PlaylistRepository(this);
        String id = getIntent().getStringExtra("channel_id");
        channels = repo.getChannels();
        for (int i = 0; i < channels.size(); i++) if (channels.get(i).id.equals(id)) { index = i; break; }
        if (index < 0) index = 0;

        LinearLayout root = Ui.column(this);
        TextView title = Ui.body(this, getIntent().getStringExtra("channel_name"));
        root.addView(title, new LinearLayout.LayoutParams(-1, Ui.dp(this, 48)));
        PlayerView pv = new PlayerView(this);
        pv.setUseController(true);
        root.addView(pv, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        player = new ExoPlayer.Builder(this).build();
        pv.setPlayer(player);
        playCurrent();
    }

    private void playCurrent() {
        if (channels == null || channels.isEmpty() || index < 0 || index >= channels.size()) return;
        Channel c = channels.get(index);
        player.setMediaItem(MediaItem.fromUri(c.url));
        player.prepare();
        player.play();
        setTitle(c.name);
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            if (event.getKeyCode() == KeyEvent.KEYCODE_DPAD_UP || event.getKeyCode() == KeyEvent.KEYCODE_CHANNEL_UP) {
                if (!channels.isEmpty()) { index = (index + channels.size() - 1) % channels.size(); playCurrent(); }
                return true;
            }
            if (event.getKeyCode() == KeyEvent.KEYCODE_DPAD_DOWN || event.getKeyCode() == KeyEvent.KEYCODE_CHANNEL_DOWN) {
                if (!channels.isEmpty()) { index = (index + 1) % channels.size(); playCurrent(); }
                return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }

    @Override protected void onStop() { super.onStop(); if (player != null) player.pause(); }
    @Override protected void onDestroy() { if (player != null) { player.release(); player = null; } super.onDestroy(); }
}
