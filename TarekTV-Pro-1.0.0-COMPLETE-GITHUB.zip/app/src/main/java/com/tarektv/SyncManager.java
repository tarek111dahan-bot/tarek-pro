package com.tarektv;

import android.content.Context;

import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import java.util.concurrent.TimeUnit;

public final class SyncManager {
    private static final String UNIQUE_NAME = "tarek_tv_periodic_sync";
    private SyncManager() {}

    public static void schedule(Context context) {
        PlaylistRepository repo = new PlaylistRepository(context);
        WorkManager wm = WorkManager.getInstance(context);
        if (!repo.getAutoSync()) {
            wm.cancelUniqueWork(UNIQUE_NAME);
            return;
        }
        Constraints constraints = new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build();
        PeriodicWorkRequest request = new PeriodicWorkRequest.Builder(SyncWorker.class, 12, TimeUnit.HOURS)
                .setConstraints(constraints)
                .build();
        wm.enqueueUniquePeriodicWork(UNIQUE_NAME, ExistingPeriodicWorkPolicy.KEEP, request);
    }
}
