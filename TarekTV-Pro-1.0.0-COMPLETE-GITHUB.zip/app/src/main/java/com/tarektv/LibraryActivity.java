package com.tarektv;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class LibraryActivity extends AppCompatActivity {
    private PlaylistRepository repo;
    private LinearLayout list;
    private String group;
    private List<Channel> visible = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        repo = new PlaylistRepository(this);
        group = getIntent().getStringExtra("group");
        if (group == null) group = "القنوات";

        LinearLayout root = Ui.column(this);
        root.addView(Ui.title(this, group.equals("__favorites__") ? "المفضلة" : group));

        EditText search = new EditText(this);
        search.setHint("ابحث في القنوات");
        search.setTextColor(android.graphics.Color.WHITE);
        search.setHintTextColor(android.graphics.Color.GRAY);
        search.setSingleLine(true);
        root.addView(search, new LinearLayout.LayoutParams(-1, Ui.dp(this, 68)));

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        search.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) { render(s.toString()); }
            public void afterTextChanged(android.text.Editable s) {}
        });

        render("");
    }

    private void render(String query) {
        list.removeAllViews();
        List<Channel> all = "__favorites__".equals(group) ? repo.getFavorites() : repo.getChannels();
        visible.clear();
        String q = query.toLowerCase(Locale.ROOT).trim();
        for (Channel c : all) {
            if (!"__favorites__".equals(group) && !"القنوات".equals(group) && !c.group.toLowerCase(Locale.ROOT).contains(group.substring(0, Math.min(4, group.length())).toLowerCase(Locale.ROOT))) continue;
            if (!q.isEmpty() && !c.name.toLowerCase(Locale.ROOT).contains(q)) continue;
            visible.add(c);
        }
        if (visible.isEmpty()) {
            list.addView(Ui.body(this, getString(R.string.no_channels)));
            return;
        }
        for (int i = 0; i < visible.size(); i++) {
            Channel c = visible.get(i);
            Button b = Ui.cardButton(this, c.name + "\n" + c.group);
            b.setTextSize(17);
            b.setOnClickListener(v -> openPlayer(c));
            b.setOnLongClickListener(v -> { repo.toggleFavorite(c.id); Toast.makeText(this, repo.isFavorite(c.id) ? "أضيفت للمفضلة" : "أزيلت من المفضلة", Toast.LENGTH_SHORT).show(); return true; });
            b.setOnKeyListener((v, keyCode, event) -> {
                if (event.getAction() == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_DPAD_CENTER) {
                    openPlayer(c); return true;
                }
                return false;
            });
            list.addView(b, new LinearLayout.LayoutParams(-1, Ui.dp(this, 82)));
        }
    }

    private void openPlayer(Channel c) {
        Intent i = new Intent(this, PlayerActivity.class);
        i.putExtra("channel_id", c.id);
        i.putExtra("channel_name", c.name);
        i.putExtra("channel_url", c.url);
        startActivity(i);
    }
}
