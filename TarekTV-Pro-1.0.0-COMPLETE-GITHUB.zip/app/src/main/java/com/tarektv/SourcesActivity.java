package com.tarektv;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

public final class SourcesActivity extends AppCompatActivity {
    private LinearLayout root;
    private PlaylistRepository repo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        repo = new PlaylistRepository(this);
        root = Ui.column(this);
        setContentView(root);
        render();
    }

    private void render() {
        root.removeAllViews();
        root.addView(Ui.title(this, getString(R.string.sources)));
        Button add = Ui.cardButton(this, getString(R.string.add_source));
        add.setOnClickListener(v -> startActivity(new Intent(this, AddSourceActivity.class)));
        root.addView(add, new LinearLayout.LayoutParams(-1, Ui.dp(this, 74)));

        if (repo.getSources().isEmpty()) {
            root.addView(Ui.body(this, getString(R.string.no_sources)));
            return;
        }
        for (Source s : repo.getSources()) {
            Button b = Ui.cardButton(this, s.name + "\n" + s.url);
            b.setTextSize(15);
            b.setOnClickListener(v -> syncOne(s));
            root.addView(b, new LinearLayout.LayoutParams(-1, Ui.dp(this, 90)));
        }
    }

    private void syncOne(Source source) {
        new Thread(() -> {
            try {
                java.util.List<Channel> c = M3uParser.parseUrl(source.url);
                repo.mergeChannels(c);
                runOnUiThread(() -> android.widget.Toast.makeText(this, "تم تحديث " + c.size() + " قناة", android.widget.Toast.LENGTH_SHORT).show());
            } catch (Exception e) {
                runOnUiThread(() -> android.widget.Toast.makeText(this, "تعذر تحديث المصدر", android.widget.Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (root != null) render();
    }
}
