package com.tarektv;

import android.app.Application;

public final class TarekTvApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        SyncManager.schedule(this);
    }
}
