package com.tarektv;

import org.json.JSONException;
import org.json.JSONObject;

public final class Channel {
    public final String id;
    public final String name;
    public final String url;
    public final String group;
    public final String logo;

    public Channel(String id, String name, String url, String group, String logo) {
        this.id = id;
        this.name = name;
        this.url = url;
        this.group = group;
        this.logo = logo;
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("name", name);
        o.put("url", url);
        o.put("group", group);
        o.put("logo", logo);
        return o;
    }

    public static Channel fromJson(JSONObject o) {
        return new Channel(
                o.optString("id"),
                o.optString("name", "قناة بدون اسم"),
                o.optString("url"),
                o.optString("group", "عام"),
                o.optString("logo")
        );
    }
}
