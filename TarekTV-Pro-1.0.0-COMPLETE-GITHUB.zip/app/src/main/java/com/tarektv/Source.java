package com.tarektv;

import org.json.JSONObject;

public final class Source {
    public final String id;
    public final String name;
    public final String url;
    public final long updatedAt;

    public Source(String id, String name, String url, long updatedAt) {
        this.id = id;
        this.name = name;
        this.url = url;
        this.updatedAt = updatedAt;
    }

    public JSONObject toJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("id", id);
            o.put("name", name);
            o.put("url", url);
            o.put("updatedAt", updatedAt);
        } catch (Exception ignored) {
        }
        return o;
    }

    public static Source fromJson(JSONObject o) {
        return new Source(o.optString("id"), o.optString("name"), o.optString("url"), o.optLong("updatedAt"));
    }
}
