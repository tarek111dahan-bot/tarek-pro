package com.tarektv;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class Ui {
    private Ui() {}

    public static int dp(Context c, int v) { return Math.round(v * c.getResources().getDisplayMetrics().density); }

    public static TextView title(Context c, String text) {
        TextView tv = new TextView(c);
        tv.setText(text);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(28);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(c, 18), dp(c, 18), dp(c, 18), dp(c, 12));
        return tv;
    }

    public static Button cardButton(Context c, String text) {
        Button b = new Button(c);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(18);
        b.setAllCaps(false);
        b.setFocusable(true);
        b.setBackgroundResource(R.drawable.card_bg);
        return b;
    }

    public static TextView body(Context c, String text) {
        TextView tv = new TextView(c);
        tv.setText(text);
        tv.setTextColor(Color.LTGRAY);
        tv.setTextSize(16);
        tv.setPadding(dp(c, 18), dp(c, 8), dp(c, 18), dp(c, 8));
        return tv;
    }

    public static LinearLayout column(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(c, 20), dp(c, 20), dp(c, 20), dp(c, 20));
        l.setBackgroundColor(c.getColor(R.color.tarek_bg));
        return l;
    }

    public static GradientDrawable rounded(int color, int radiusDp, Context c) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(c, radiusDp));
        return d;
    }
}
