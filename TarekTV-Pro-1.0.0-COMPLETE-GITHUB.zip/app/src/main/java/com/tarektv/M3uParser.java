package com.tarektv;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class M3uParser {
    private static final Pattern ATTR_PATTERN = Pattern.compile("([\\w-]+)=\\\"([^\\\"]*)\\\"");

    private M3uParser() {}

    public static List<Channel> parseUrl(String url) throws Exception {
        URLConnection connection = new URL(url).openConnection();
        connection.setConnectTimeout(15000);
        connection.setReadTimeout(30000);
        connection.setRequestProperty("User-Agent", "TarekTV-Pro/1.0.0");
        try (InputStream in = connection.getInputStream()) {
            return parseStream(in);
        }
    }

    public static List<Channel> parseStream(InputStream input) throws Exception {
        List<Channel> result = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
            String line;
            String info = null;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.equalsIgnoreCase("#EXTM3U")) continue;
                if (line.startsWith("#EXTINF")) {
                    info = line;
                } else if (!line.startsWith("#") && info != null) {
                    String title = extractTitle(info);
                    String group = extractAttribute(info, "group-title", "عام");
                    String logo = extractAttribute(info, "tvg-logo", "");
                    String id = extractAttribute(info, "tvg-id", "");
                    if (id.isEmpty()) id = UUID.nameUUIDFromBytes((title + "|" + line).getBytes(StandardCharsets.UTF_8)).toString();
                    result.add(new Channel(id, title, line, group, logo));
                    info = null;
                }
            }
        }
        return result;
    }

    private static String extractTitle(String info) {
        int comma = info.indexOf(',');
        if (comma >= 0 && comma + 1 < info.length()) return info.substring(comma + 1).trim();
        return "قناة بدون اسم";
    }

    private static String extractAttribute(String info, String name, String fallback) {
        Matcher m = ATTR_PATTERN.matcher(info);
        while (m.find()) if (name.equalsIgnoreCase(m.group(1))) return m.group(2);
        return fallback;
    }
}
