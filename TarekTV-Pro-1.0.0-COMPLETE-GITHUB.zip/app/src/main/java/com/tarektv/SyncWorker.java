package com.tarektv;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import java.util.List;

public final class SyncWorker extends Worker {
    public SyncWorker(@NonNull Context appContext, @NonNull WorkerParameters params) {
        super(appContext, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        PlaylistRepository repo = new PlaylistRepository(getApplicationContext());
        if (!repo.getAutoSync()) return Result.success();
        boolean hadFailure = false;
        for (Source source : repo.getSources()) {
            try {
                List<Channel> channels = M3uParser.parseUrl(source.url);
                if (!channels.isEmpty()) repo.mergeChannels(channels);
            } catch (Exception e) {
                hadFailure = true;
            }
        }
        return hadFailure ? Result.retry() : Result.success();
    }
}
