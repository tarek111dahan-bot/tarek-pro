# Tarek TV uses explicit Android components; no custom shrinking rules are required for debug builds.
