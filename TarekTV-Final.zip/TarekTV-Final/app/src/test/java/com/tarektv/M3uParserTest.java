package com.tarektv;
import com.tarektv.data.M3uParser;import org.junit.Test;import static org.junit.Assert.*;
public class M3uParserTest{@Test public void parses(){String s="#EXTM3U\n#EXTINF:-1 tvg-name=\"News\" group-title=\"News\",News\nhttps://example.com/a.m3u8\n";assertEquals(1,M3uParser.parse(s).size());assertEquals("News",M3uParser.parse(s).get(0).name);}}
