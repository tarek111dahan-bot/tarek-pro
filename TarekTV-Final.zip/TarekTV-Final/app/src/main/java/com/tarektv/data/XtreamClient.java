package com.tarektv.data;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;

/** Minimal Xtream API client. It deliberately returns raw JSON so the app can evolve without losing fields. */
public final class XtreamClient {
    private XtreamClient() {}
    public static String request(String server, String username, String password, String action) throws IOException {
        String base=server.endsWith("/")?server.substring(0,server.length()-1):server;
        String q=base+"/player_api.php?username="+URLEncoder.encode(username,"UTF-8")+"&password="+URLEncoder.encode(password,"UTF-8");
        if(action!=null&&!action.isEmpty()) q += "&action="+URLEncoder.encode(action,"UTF-8");
        HttpURLConnection c=(HttpURLConnection)new URL(q).openConnection(); c.setConnectTimeout(15000); c.setReadTimeout(30000); c.setRequestProperty("User-Agent","TarekTV/1.0 Android");
        try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)out.write(b,0,n);return out.toString(StandardCharsets.UTF_8.name());} finally{c.disconnect();}
    }
}
