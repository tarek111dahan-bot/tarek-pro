package com.tarektv.data;
import androidx.room.*; import java.util.*;
@Dao public interface MediaDao { @Query("SELECT * FROM media_items ORDER BY name") List<MediaItem> all(); @Query("SELECT * FROM media_items WHERE type=:type ORDER BY name") List<MediaItem> byType(String type); @Query("SELECT * FROM media_items WHERE name LIKE '%' || :q || '%' ORDER BY name") List<MediaItem> search(String q); @Insert(onConflict=OnConflictStrategy.REPLACE) void insertAll(List<MediaItem> items); @Query("DELETE FROM media_items") void clear(); @Update void update(MediaItem item); }
