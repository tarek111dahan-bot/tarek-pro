package com.tarektv.data;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName="media_items")
public class MediaItem {
    @PrimaryKey(autoGenerate=true) public long id;
    public String name;
    public String url;
    public String groupName;
    public String logo;
    public String type;
    public String subtitle;
    public boolean favorite;
    public long positionMs;
}
