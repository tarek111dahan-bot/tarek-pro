package com.tarektv.worker;
import android.content.Context;
import androidx.annotation.NonNull;
import androidx.work.*;
import com.tarektv.data.SourceRepository;
import java.util.concurrent.CountDownLatch;

public class SourceUpdateWorker extends Worker {
 public SourceUpdateWorker(@NonNull Context c,@NonNull WorkerParameters p){super(c,p);}
 @NonNull @Override public Result doWork(){try{CountDownLatch latch=new CountDownLatch(1);new SourceRepository(getApplicationContext()).syncAll(latch::countDown);latch.await();return Result.success();}catch(Exception e){return Result.retry();}}
}
