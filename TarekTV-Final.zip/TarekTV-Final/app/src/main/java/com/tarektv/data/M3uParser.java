package com.tarektv.data;
import java.util.*; import java.util.regex.*;
public final class M3uParser {
 private M3uParser(){}
 public static List<MediaItem> parse(String text){ List<MediaItem> out=new ArrayList<>(); String[] lines=text.replace("\r","").split("\n"); String name=null,group="",logo="",type="live"; for(String raw:lines){String line=raw.trim(); if(line.isEmpty()) continue; if(line.startsWith("#EXTINF")){ name=attr(line,"tvg-name"); if(name==null||name.isEmpty()){int comma=line.indexOf(','); name=comma>=0?line.substring(comma+1).trim():"قناة";} group=attr(line,"group-title"); logo=attr(line,"tvg-logo"); type=guessType(group,name); } else if(!line.startsWith("#") && name!=null){MediaItem m=new MediaItem();m.name=name;m.url=line;m.groupName=group;m.logo=logo;m.type=type;out.add(m);name=null;} } return out; }
 private static String attr(String s,String key){Matcher m=Pattern.compile(key+"=\\\"([^\\\"]*)\\\"",Pattern.CASE_INSENSITIVE).matcher(s);return m.find()?m.group(1):"";}
 private static String guessType(String g,String n){String s=(g+" "+n).toLowerCase(Locale.ROOT);if(s.contains("movie")||s.contains("film")||s.contains("فيلم"))return "movie";if(s.contains("series")||s.contains("مسلسل"))return "series";if(s.contains("sport")||s.contains("رياض"))return "sport";if(s.contains("islam")||s.contains("قرآن")||s.contains("quran"))return "islamic";return "live";}
}
