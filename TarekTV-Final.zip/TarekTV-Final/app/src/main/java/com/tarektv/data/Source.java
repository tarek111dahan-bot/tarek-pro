package com.tarektv.data;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
@Entity(tableName="sources") public class Source { @PrimaryKey(autoGenerate=true) public long id; public String name; public String url; public String kind; public boolean enabled=true; }
