package com.tarektv.data;
import androidx.room.*; import java.util.*;
@Dao public interface SourceDao { @Query("SELECT * FROM sources ORDER BY id DESC") List<Source> all(); @Insert(onConflict=OnConflictStrategy.REPLACE) long insert(Source source); @Delete void delete(Source source); }
