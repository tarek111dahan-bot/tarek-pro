package com.tarektv.data;
import android.content.Context; import androidx.room.*;
@Database(entities={MediaItem.class,Source.class},version=1,exportSchema=false)
public abstract class AppDatabase extends RoomDatabase { public abstract MediaDao media(); public abstract SourceDao sources(); private static volatile AppDatabase INSTANCE; public static AppDatabase get(Context c){ if(INSTANCE==null){ synchronized(AppDatabase.class){ if(INSTANCE==null) INSTANCE=Room.databaseBuilder(c.getApplicationContext(),AppDatabase.class,"tarek_tv.db").fallbackToDestructiveMigration().build(); } } return INSTANCE; } }
